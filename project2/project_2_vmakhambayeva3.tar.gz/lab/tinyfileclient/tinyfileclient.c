
#include "../common/common.h"
#include "../common/cmdlineArgs.h"
#include <time.h>

#define MAX_FILE_COUNT 2048

int createJobId(TinyState* ts)
{
    static int jobCounter = 0;

    ++jobCounter;
    return (ts->clientId << 16 | jobCounter);
}

void startup(TinyState* ts)
{
    ensure(ts->segmentCount > 0 && ts->segmentSize > 0, "Wrong segment size/count");

    printf("TinyFile client starting...\n");

    ts->qid = open_msg_queue();
    printf("  - msg queue opened...\n");

    open_segment(SEGMENT_NAME, ts->segmentCount * ts->segmentSize, &ts->fd, &ts->memptr);
    printf("  - shared memory segments allocated...\n");
    
    printf("Done.\n\n");
}

void sendMessage(int qid, int message, int jobId, int size, const char* filename)
{
    MessageForServer msg = {0};
    msg.msgSize = sizeof(MessageForServer);
    msg.type = message;
    msg.jobId = jobId;
    msg.size = size;
    if (filename != NULL)
    {
        strcpy(msg.filename, filename);
    }
    
    msgsnd(qid, &msg, sizeof(msg), IPC_NOWAIT);

    if (verbose) printf("Send %s: jobId = %d, size = %d\n", msg_as_string(message), jobId, size);
}

void waitForMessage(int qid, int jobId, MessageForClient* msg)
{
    memset(msg, 0, sizeof(MessageForClient));
    if (msgrcv(qid, msg, sizeof(MessageForClient) - sizeof(long), jobId, MSG_NOERROR) < 0)
    {
         report_and_exit("msgrcv failure.");
    }

    if (msg->msgSize != sizeof(MessageForClient))
    {
        printf("Protocol error, malformed message received! Expected size is %ld, received %d", sizeof(MessageForClient), msg->msgSize);
        exit(-1);
    }

    if (verbose) printf("Received %s: jobId = %ld, size = %d, segment = %d\n", msg_as_string(msg->type), msg->jobId, msg->size, msg->segment);
}

bool checkForMessage(int qid, int jobId, MessageForClient* msg)
{
    memset(msg, 0, sizeof(MessageForClient));
    if (msgrcv(qid, msg, sizeof(MessageForClient) - sizeof(long), jobId, MSG_NOERROR | IPC_NOWAIT) < 0)
    {
        // Check if call failed because there is no suitable messages in the queue. It can happen and it's OK.
        if (errno == ENOMSG)
        {
            return false;
        }

        // Something else went wrong.
        report_and_exit("msgrcv failure.");
    }

    if (msg->msgSize != sizeof(MessageForClient))
    {
        printf("Protocol error, malformed message received! Expected size is %ld, received %d", sizeof(MessageForClient), msg->msgSize);
        exit(-1);
    }

    if (verbose) printf("Received message %s: size = %d\n", msg_as_string(msg->type), msg->size);
    return true;
}

// Notes for myself
// ----------------
//
// Async API: CompressFileAsync(fileName) --> jobId; 
//            CheckIfResultReady(jobId) --> bool, result; // non-blocking 
//            WaitUntilResultReady(jobId) --> result; // blocking
//
// Sync API: CompressFileSync(filename) --> result
//
// Multiple segments:
//  - When server gets "request-to-send", it sends back "jobId" to be used instead of clientId. 
//  - Then client can have parallel jobs running.
//  - JobIds have to be unique between clients, so client will use unique clientId as base to generate them.
//  - Server will not know about clients, only about jobs. One job - one request to compress file 
//    (QoS unfortunately, will require changes here).
//  - Because we assign a segment for a job until it's done - we may have lower throughput in async cases,
//    when segment will be "idle" while we wait until user comes back to receive data. Upsides: receving is
//    guaranteed to have a slot if file was sent successfully, so latency will be more predictable. And logic
//    is simpler.
//  
// TODO
//  - Add ability to point client to a segment via index or offset from start. 
//  - Maybe add ability to queue work when all slots are busy, instead of kicking off clients with "SERVER_FULL". 
//    We now can handle max number of parallel uploads == number of segments, which sounds like plenty. But that 
//    might force clients to do repeats.
//  - Forgot about strdup, check for places where to use it.
//

// Async API - this method will send file out and exit. 
// Use checkIfReady()/wait_until_ready() to retrieve results.
bool compressAsync(TinyState* ts, TinyJob* job)
{
    ensure(job->outgoingBytes != NULL && job->incomingBytes == NULL, "Job should be in sending mode!");
    ensure(job->offset == 0, "Job shouldn't be started yet");

    // Initiate send
    sendMessage(ts->qid, TINYMSG_START_TRANSMISSION, job->id, job->outgoingSize, job->filename);

    do 
    {
        MessageForClient msg = {0};
        waitForMessage(ts->qid, job->id, &msg);
        
        if (msg.type == TINYMSG_READY_TO_RECEIVE)
        {
            job->segment = msg.segment;

            // Server tells us that we allowed to copy next chunk of the file to a shared segment. 
            // Segment size which we allowed to use is passed back in message as msg.size. Copy 
            // bytes to shared segment
            int bytesSent = fillBuffer(segPtr(ts, job), msg.size, job->outgoingBytes, job->offset, job->outgoingSize);
            job->offset += bytesSent;
            
            if (verbose) printf("Sent %d bytes. Total %d of %d (%s)...\n", bytesSent, job->offset, job->outgoingSize, job->filename);

            // And notify server that data is ready.
            sendMessage(ts->qid, TINYMSG_NOTIFY_DATA_SENT, job->id, bytesSent, NULL);
        }
        else if (msg.type == TINYMSG_SERVER_IS_FULL)
        {
            ensure(job->offset == 0, "TINYMSG_SERVER_IS_FULL can't be received in the middle of transmission.");

            // Alas, we can't do anything now. 
            return false;
        }
        else
        {
            printf("Unexpected message received: %s, size = %d", msg_as_string(msg.type), msg.size);
            exit(-1);
        }
    }
    while (job->outgoingSize - job->offset > 0);  // Repeat until we send whole file.

    return true;
}

bool checkIfReadyMaybeWait(TinyState* ts, TinyJob* job, bool waitForResult)
{
    ensure(job->outgoingBytes != NULL && job->incomingBytes == NULL, "The job should still be in sending mode!");
    ensure(job->outgoingSize == job->offset, "Not all outgoing data was sent to server!");

    bool firstIteration = true;
    do 
    {
        // We can early-out if there is no messages for us only on first iteration. 
        // If server started to send data to us - we will wait until full file is received.
        MessageForClient msg = {0};
        if (waitForResult || !firstIteration)
        {
            waitForMessage(ts->qid, job->id, &msg);
        }
        else if (!checkForMessage(ts->qid, job->id, &msg))
        {
            return false;
        }
        
        if (msg.type == TINYMSG_START_TRANSMISSION)
        {
            // Client sent out whole file, it was received & processed by server,
            // now client need to switch job to receiving mode. Clear outgoing part
            free(job->outgoingBytes);
            job->outgoingBytes = NULL;
            job->outgoingSize = 0;
            job->offset = 0;

            // Allocate buffer for incoming data.
            job->incomingSize = msg.size;
            job->incomingBytes = malloc(job->incomingSize);
            job->offset = 0;
        }
        else if (msg.type == TINYMSG_NOTIFY_DATA_SENT)
        {
            // Server put data into shared segment for us. 
            ensure(job->incomingBytes != NULL && job->outgoingBytes == NULL, "The job should be in receiving mode!");

            // Save it.
            memcpy(job->incomingBytes + job->offset, segPtr(ts, job), msg.size);
            job->offset += msg.size;

            if (verbose) printf("Received %d bytes more. Total: %d of %d for (%s)\n", msg.size, job->offset, job->incomingSize, job->filename);

            // Notify server we received it. 
            sendMessage(ts->qid, TINYMSG_READY_TO_RECEIVE, job->id, -1, NULL);

            if (job->incomingSize == job->offset)
            {
                // We received full processed file back from server. Job is done. 
                printf("Job (%s) is done. Received %d bytes.\n", job->filename, job->incomingSize);
                if (verbose) printf("Content received: %s\n\n", job->incomingBytes);
            }
        }
        else
        {
            printf("Unexpected message received: %s, size = %d", msg_as_string(msg.type), msg.size);
            exit(-1);
        }

        firstIteration = false;
    }
    while (job->incomingBytes == NULL || job->incomingSize - job->offset > 0);  // Repeat until we get file.

    return true;
}

// Async API: checks if result is available for a given job. If it is - retrieves it.
bool checkIfReady(TinyState* ts, TinyJob* job)
{
    return checkIfReadyMaybeWait(ts, job, false);
}

// Async API: waits for a result for a given job.
void waitUntilReady(TinyState* ts, TinyJob* job)
{
    checkIfReadyMaybeWait(ts, job, true);
}

// Sync API just utilizes blocking method which will wait for results.
bool compressSync(TinyState* ts, TinyJob* job)
{
    if (compressAsync(ts, job))
    {
        waitUntilReady(ts, job);
        return true;
    }

    return false;
}

// To make things easier collect all files we need to send into single array.
void gatherFileNames(CmdlineArgs* cmdlineArgs, char** allFileNames, int* fileCount, int maxFileCount)
{
    *fileCount = 0;

    // Grab input first. We verified that it exists when parsed args.
    if (cmdlineArgs->inputFileName != NULL)
    {
        allFileNames[(*fileCount)++] = cmdlineArgs->inputFileName;
    }

    // Now process filenames list if present
    if (cmdlineArgs->listFileName != NULL)
    {
        FILE* file = fopen(cmdlineArgs->listFileName, "r");
        if (file == NULL)
        {
            printf("Can't open list of input files '%s'\n", cmdlineArgs->listFileName);
            report_and_exit("fopen returned NULL");
        }

        char *line = NULL;
        size_t len = 0;
        while (getline(&line, &len, file) != -1) 
        {
            // Grab line if it represents valid fileName
            if (line != NULL && strlen(line) > 0)
            {
                // There are probably better way to remove those.
                int l = strlen(line);
                for (int i = 0; i < l; ++i)
                {
                    if (line[i] == '\n' || line[i] == '\r')
                    {
                        line[i] = 0;
                    }
                }
                
                if (strlen(line) > 0)
                {
                    allFileNames[(*fileCount)++] = line;
                    line = NULL;

                    if (*fileCount >= maxFileCount)
                    {
                        printf("Wow, that's really big list of files. Will use only first %d entries.", *fileCount);
                        fclose(file);
                        return;
                    }
                }
            }
            else
            {
                printf("Line '%s' doesn't represent filename, skipping it.\n", line);
            }
        }

        free(line);
        fclose(file);
    }
}

void freeFileNames(char** allFileNames, int fileCount)
{
    for (int i = 0; i < fileCount; ++i)
    {
        free(allFileNames[i]);
        allFileNames[i] = NULL;
    }
}

bool readFile(const char* fileName, char** buffer, int* size)
{
    ensure(*buffer == NULL, "readFile expects to receive empty buffer.");

    FILE *file = fopen(fileName, "rb");
    if (file == NULL)
    {
        perror("readFile: fopen returned NULL");
        printf("Can't open file '%s'\n", fileName);
        exit(-1);
    }

    fseek(file, 0, SEEK_END);
    long fileSize = ftell(file);
    fseek(file, 0, SEEK_SET); 

    *buffer = malloc(fileSize);
    fileSize = fread(*buffer, 1, fileSize, file);
    *size = fileSize;
    if (fileSize == 0)
    {
        printf("Can't read data from '%s'.\n", fileName);
        free(*buffer);
        *buffer = NULL;
    }
    
    fclose(file);

    return (*buffer != NULL);
}

// Saves file at the same path with postfix ".compressed". 
void writeFile(const char* originalFileName, char* buffer, int size)
{
    char newFileName[1024] = {0};
    strcpy(newFileName, originalFileName);
    strcat(newFileName, ".compressed");

    FILE* file = fopen(newFileName, "wb");
    if (file == NULL)
    {
        printf("Can't save file '%s'\n", newFileName);
        exit(-1);
    }
    
    size_t bytesWritten = fwrite(buffer, 1, size, file);
    if (bytesWritten != (size_t)size)
    {
        printf("Uh-oh, something went wrong. Only %ld of %d bytes were written for '%s'\n", bytesWritten, size, newFileName);
    }

    fclose(file);
}

double getDuration(clock_t* start)
{
    clock_t stop = clock();
    return (double)(stop - *start) * 1000.0 / CLOCKS_PER_SEC;
}

bool createJob(TinyState* ts, TinyJob* job, const char* filename)
{
    reset(job);

    job->id  = createJobId(ts);
    strcpy(job->filename, filename);
    if (readFile(filename, &job->outgoingBytes, &job->outgoingSize))
    {
        return true;
    }

    reset(job);
    return false;
}

void sendFilesAsync(TinyState* ts, char** allFileNames, int fileCount)
{
    // Here we kinda trying to show potential async nature. But because 
    // we are running on a single thread, we can't really get a lot of benefits.
    // If we pretent, that sending & receiving is fast, but compression on server
    // is slow (which is not true) - then we might want to send few files, do something 
    // usefull, then check results. This code will try to emulate this.

    #define jobCount 2
    TinyJob parallelJobs[jobCount] = {0};
    double durations[jobCount] = {0};

    int fileIndex = 0;
    while (fileIndex < fileCount)
    { 
	     for (int i = 0; i < jobCount; ++i)
        {
            reset(&parallelJobs[i]);
        }
        // Send out up to jobCount requests to server
        int i = 0; 
        while (i < jobCount && fileIndex < fileCount)
        {
            if (createJob(ts, &parallelJobs[i], allFileNames[fileIndex]))
            {
                clock_t start = clock();
                if (!compressAsync(ts, &parallelJobs[i]))
                {
                    // Alternatively we could wait & retry, but it's messy and not very interesting.
                    fatalError("We don't handle overloaded server scenario here.\n");
                }
                durations[i] = getDuration(&start);

                printf("Sent '%s' for processing\n", allFileNames[fileIndex]);

                ++i;
            }

            ++fileIndex;
        }

        // Here we pretend to do some useful work while server processed our data.
        printf("Working really hard...\n");

        // And then retrieve results. For fun let's do it in reverse order.
        for (int i = jobCount - 1; i >= 0; --i)
        {
            if (!isFree(&parallelJobs[i]))
            {
                clock_t start = clock();
                waitUntilReady(ts, &parallelJobs[i]);
                durations[i] += getDuration(&start);

                printf("CST for %s was %.3f ms\n", parallelJobs[i].filename, durations[i]);
            }
        }
    }

    #undef jobCount
}

int main(int argc, char* argv[])
{
    CmdlineArgs cmdlineArgs;
    parseCmdlineArgs(argc, argv, &cmdlineArgs);
    verifyArgsForClient(&cmdlineArgs);

    TinyState ts = {0};
    ts.segmentCount = cmdlineArgs.segmentCount;
    ts.segmentSize =  cmdlineArgs.segmentSize;

    // Can be figured out between server and client, but it will complicate protocol.
    // For now we expect each client to have unique id assigned by user on start.
    // Client's id should start from CLIENT_ID_BASE, so they don't clash with TINYMSG_* ids
    // from common.h
    ts.clientId = CLIENT_ID_BASE + cmdlineArgs.clientId;

    startup(&ts);

    int fileCount = 0;
    char* allFileNames[MAX_FILE_COUNT] = {0}; 
    gatherFileNames(&cmdlineArgs, allFileNames, &fileCount, MAX_FILE_COUNT);
    
    if (!cmdlineArgs.asyncMode)
    {
        for (int i = 0; i < fileCount; ++i)
        {
            TinyJob job;
            if (createJob(&ts, &job, allFileNames[i]))
            {
                clock_t start = clock();
                compressSync(&ts, &job);
                double duration = getDuration(&start);
                printf("CST for %s was %.3f ms\n", job.filename, duration);

                writeFile(allFileNames[i], job.incomingBytes, job.incomingSize);
            }

            reset(&job);
        }
    }
    else
    {
        sendFilesAsync(&ts, allFileNames, fileCount);
    }

    freeFileNames(allFileNames, fileCount);

    return 0;
}
