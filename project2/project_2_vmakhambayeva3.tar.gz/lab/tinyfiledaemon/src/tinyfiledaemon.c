#include "../../common/common.h"
#include "../../common/cmdlineArgs.h"
#include "../snappyc/snappy.h"
#include <signal.h>

// So we don't have to write 'struct snappy_env' 
typedef struct snappy_env snappy_env;

// Params
TinyJob* jobs = NULL;

void startup(TinyState* ts, snappy_env* snappy)
{
    printf("TinyFile server starting...\n");

    // Open, close and re-open to flush any messages left from previous run.
    // Maybe there is a better way?
    ts->qid = open_msg_queue();
    delete_msg_queue(ts->qid);
    ts->qid = open_msg_queue();
    printf("  - msg queue opened...\n");

    create_segment(SEGMENT_NAME, ts->segmentSize * ts->segmentCount, &ts->fd, &ts->memptr);
    printf("  - shared memory segments allocated...\n");
    
    if (snappy_init_env(snappy))
    {
         fatalError("Failed to initialize snappy.");
    }
    printf("  - snappy initialized...\n");

    jobs = calloc(ts->segmentCount, sizeof(TinyJob));
    printf("  - job slots allocated...\n");
    
    printf("Done.\n\n");
}

void shutdown(TinyState* ts, snappy_env* snappy)
{
    printf("TinyFile server shutting down...\n");

    close_segment(SEGMENT_NAME, ts->segmentCount * ts->segmentSize, ts->fd, ts->memptr);
    delete_msg_queue(ts->qid);

    snappy_free_env(snappy);

    printf("TinyFile server shutdown.\n\n");
}

void sendMessage(int qid, int message, int jobId, int size, int segment)
{
    MessageForClient msg  = {0};
    msg.msgSize = sizeof(MessageForClient);
    msg.jobId = jobId;
    msg.type = message;
    msg.size = size;
    msg.segment = segment;
    msgsnd(qid, &msg, sizeof(msg), IPC_NOWAIT);

    if (verbose) printf("Send %s: jobId = %d, size = %d, segment = %d\n", msg_as_string(message), jobId, size, segment);
}

void waitForMessage(int qid, MessageForServer* msg)
{
    memset(msg, 0, sizeof(MessageForServer));
    if (msgrcv(qid, msg, sizeof(MessageForServer) - sizeof(long), -CLIENT_ID_BASE, MSG_NOERROR) < 0)
    {
        report_and_exit("msgrcv failure.");
    }

    if (msg->msgSize != sizeof(MessageForServer))
    {
        printf("Protocol error, malformed message received!");
        exit(-1);
    }

    ensure(msg->jobId != 0, "jobId can't be zero.");

    if (verbose) printf("Received message %s: jobId = %d, size = %d\n", msg_as_string(msg->type), msg->jobId, msg->size);
}

void compressIncomingBytes(snappy_env* snappy, TinyJob* job)
{
    ensure(job->incomingBytes != NULL && job->incomingSize != 0, "No data to compress!");

    size_t compressedSize = snappy_max_compressed_length(job->incomingSize);
    job->outgoingBytes = malloc(compressedSize);
    
    if (snappy_compress(snappy, job->incomingBytes, job->incomingSize, job->outgoingBytes, &compressedSize))
    {
        fatalError("Snappy failed to compress buffer");
    }

    job->outgoingSize = compressedSize;

    printf("Snappy compression: %d --> %d bytes.\n", job->incomingSize, job->outgoingSize);

    // This piece of code is handy to use in tests, instead of snappy
    // (void)snappy;
    // int n = job->incomingSize;
    // job->outgoingSize = n;
    // job->outgoingBytes = malloc(n);
    // for (int i = 0; i < n; ++i)
    // {
    //     job->outgoingBytes[i] = job->incomingBytes[n - i - 1];
    // }
    // job->outgoingBytes[0] = job->outgoingBytes[n - 1];
    // job->outgoingBytes[n - 1] = 0;
    
}

// Advance given job according to it's current state & received message.
void processMessage(TinyState* ts, snappy_env* snappy, MessageForServer* msg, TinyJob* job)
{
    if (msg->type == TINYMSG_NOTIFY_DATA_SENT) 
    {
        // Client notified us that he sent next chunk of a file.
        ensure(job->incomingBytes != NULL && job->outgoingBytes == NULL, "The job should be in receiving mode!");

        // Store it to job's buffer
        memcpy(job->incomingBytes + job->offset, segPtr(ts, job), msg->size);
        job->offset += msg->size;

        if (verbose) printf("Received %d bytes. Total: %d of %d\n", msg->size, job->offset, job->incomingSize);

        // Check if full file received
        if (job->offset == job->incomingSize)
        {
            printf("Received full file (%d bytes).\n", job->incomingSize);
            if (verbose) printf("Content received: %s\n\n", job->outgoingBytes);

            // Process it
            compressIncomingBytes(snappy, job);

            // Free incoming buffer, the job is now in sending mode.
            free(job->incomingBytes);
            job->incomingBytes = NULL;
            job->incomingSize = 0;
            job->offset = 0;

            printf("Starting to send processed file (%d bytes).\n", job->outgoingSize);
            if (verbose) printf("Content to send: %s\n\n", job->outgoingBytes);

            // Tell client to prepare to receive processed file.
            sendMessage(ts->qid, TINYMSG_START_TRANSMISSION, job->id, job->outgoingSize, -1);

            // Copy first part of the outgoing file into shared segment
            int bytesSent = fillBuffer(segPtr(ts, job), ts->segmentSize, job->outgoingBytes, job->offset, job->outgoingSize);
            job->offset += bytesSent;

            // And tell client that it's waiting for him.
            sendMessage(ts->qid, TINYMSG_NOTIFY_DATA_SENT, job->id, bytesSent, job->segment);
        }
        else
        {
            // Notify client that data received and it can send next part, up to segment_size of bytes.
            sendMessage(ts->qid, TINYMSG_READY_TO_RECEIVE, job->id, ts->segmentSize, job->segment);
        }
    }
    else if (msg->type == TINYMSG_READY_TO_RECEIVE)
    {
        // Client tells us that he is ready to receive (next) chunk of processed file.
        ensure(job->outgoingBytes != NULL && job->incomingBytes == NULL, "The job should be in sending mode!");

        // So send him next chunk
        int bytesSent = fillBuffer(segPtr(ts, job), ts->segmentSize, job->outgoingBytes, job->offset, job->outgoingSize);
        job->offset += bytesSent;
        if (bytesSent > 0)
        {
            // And tell that there is data waiting for him.
            sendMessage(ts->qid, TINYMSG_NOTIFY_DATA_SENT, job->id, bytesSent, job->segment);
        }
        else
        {
            // We sent last bits in previous time, this message signals that client received whole file.
            // This job is done, clear it for re-use.
            reset(job);
        }
    }
    else
    {
        printf("Unexpected message received: %s, jobId = %d", msg_as_string(msg->type), msg->jobId);
        exit(-1);
    }
}

// Fills free job slot with passed in data and returns pointer to it. 
// If there are no free slots - returns NULL.
TinyJob* tryToStartNewJob(TinyState* ts, int jobId, int size, const char* filename)
{
    // Loop through all jobs in search of free slot. There shouldn't be many of them,
    // as we have one per segment and don't expect many segments.
    for (int i = 0; i < ts->segmentCount; ++i)
    {
        if (isFree(&jobs[i]))
        {
            // Start of a new job
            strcpy(jobs[i].filename, filename);
            jobs[i].id = jobId;
            jobs[i].segment = i;
            jobs[i].incomingSize = size;
            jobs[i].incomingBytes = malloc(size);

            return &jobs[i];
        }
    }

    return NULL;
}

// Tries to find existing job by id. Returns NULL if it is not present.
TinyJob* findExistingJob(TinyState* ts, int jobId)
{
    ensure(jobId != 0, "Active job's id can't be zero.");
    for (int i = 0; i < ts->segmentCount; ++i)
    {
        if (jobs[i].id == jobId)
        {
            return &jobs[i];
        }
    }

    return NULL;
}


int main(int argc, char* argv[])
{
    CmdlineArgs cmdlineArgs;
    parseCmdlineArgs(argc, argv, &cmdlineArgs);
    verifyArgsForServer(&cmdlineArgs);

    TinyState ts = {0};
    ts.segmentCount = cmdlineArgs.segmentCount;
    ts.segmentSize =  cmdlineArgs.segmentSize;
    snappy_env snappy;
    startup(&ts, &snappy);
    
    while (true)
    {
        // Wait for any message from clients
        MessageForServer msg = {0};
        waitForMessage(ts.qid, &msg);

        if (msg.type == TINYMSG_START_TRANSMISSION)
        {
            TinyJob* job = tryToStartNewJob(&ts, msg.jobId, msg.size, msg.filename);
            if (job != NULL)
            {
                // We had a free slot for the new job. Tell client to send up to segment_size of bytes.
                sendMessage(ts.qid, TINYMSG_READY_TO_RECEIVE, job->id, ts.segmentSize, job->segment);
            }
            else
            {
                // We don't have free slots. We could save message and wait until suck slot appears,
                // but instead we would tell client that server is too busy, as it simpler.
                sendMessage(ts.qid, TINYMSG_SERVER_IS_FULL, msg.jobId, -1, -1);
            }
        }
        else 
        {
            TinyJob* job = findExistingJob(&ts, msg.jobId);
            if (job != NULL)
            {
                processMessage(&ts, &snappy, &msg, job);
            }
            else
            {
                // Uh-oh, something went wrong. 
                printf("Error: Can't find jobId = %d among active jobs. Ignoring message %s.", msg.jobId, msg_as_string(msg.type));
            }
        }
    }

    //TODO: we never get here, find way to properly shutdown later.
    shutdown(&ts, &snappy);
   
    return 0;
}
