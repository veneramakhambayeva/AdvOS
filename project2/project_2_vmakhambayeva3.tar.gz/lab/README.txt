Notes
-----
- Make file: borrowed from here: https://github.com/mbcrawfo/GenericMakefile
(sorry for that)

How to run Tinyserver:
1)cd lab/tinyfiledaemon
2)make
3)bin/release/tinyfiledaemon --n_sms 3 --sms_size 32

How to run client:
1)cd lab/tinyfileclient
2)make
3)put files in this directory
4)bin/release/tinyfileclient --client_id 777 --n_sms 3 --sms_size 32 --file Tiny.txt --mode async
  bin/release/tinyfileclient --client_id 778 --n_sms 3 --sms_size 32 --files filelist.txt --mode sync 
5)can find compressed files in this directory
