#pragma once

#define _XOPEN_SOURCE 700
#define _XOPEN_SOURCE_EXTENDED 1

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

#include <sys/ipc.h>
#include <sys/msg.h>

#include <sys/mman.h>
#include <sys/stat.h>
#include <stdbool.h>

//
// Core constants and data structures
//

#define PROJECT_ID 42
#define QUEUE_FILENAME "/usr/bin" 
#define SEGMENT_NAME "labsharedmemory"
#define SEGMENT_ACCESS_PERM 0644

#define CLIENT_ID_BASE 1000

// Sender wants to start transmission of a file of a specified size.
#define TINYMSG_START_TRANSMISSION 1 
// Sent by server when it has free segment and ready to receive data. 
// Or by client when he read chunk of data from a segment and ready for the next.
#define TINYMSG_READY_TO_RECEIVE 2  
// Sender filled a segment with data. Size field tells how much bytes are there. 
#define TINYMSG_NOTIFY_DATA_SENT 3  
// Sent by server when there are no free slots for new jobs. 
#define TINYMSG_SERVER_IS_FULL 4

// Set to true to see more detailed logs
bool verbose = false;

// Stores main objects (queue, shared memory segments) to use.
// Used by both client and server.
typedef struct 
{
    int segmentCount;
    int segmentSize;
    int clientId;

    int fd;
    int qid; 
    char* memptr; // BUGBUG rename to something more like segments 
} TinyState;

// We need 2 types because queue allows to filter by first 'long' in the message. 
// On server we want to be able to choose type of message to read/process next.
// While on client - we want to be able to read only messages addressed to us.
typedef struct { 
    long type;
    int msgSize;
    int jobId;
    int size;
    char filename[256];
} MessageForServer;

typedef struct {
    long jobId;
    int msgSize;
    int type;
    int size;
    int segment; 
} MessageForClient;

// Info about one file/job:
//  - outgoing unprocessed bytes
//  - incoming processed bytes,
//  - filename
//  - size
typedef struct
{
    char filename[512];
    
    char* incomingBytes;
    int incomingSize;
    char* outgoingBytes;
    int outgoingSize;

    // Depending on mode: offset to next byte to send/receive. 
    // Or number of received or sent bytes, as those are the same.
    int offset;

    // Server uses ids in message queue to control read/write operations in shared memory.
    int id;

    // Index of the segment used by the job       
    int segment;
} TinyJob;

//
// Small helpers
//

#define MIN(a,b) (((a)<(b))?(a):(b))

void fatalError(const char* msg) 
{
    printf("Error: %s\n", msg);
    exit(-1); /* EXIT_FAILURE */
}

// For sanity checks - to ensure that things are in the state we expect them to be. 
void ensure(bool condition, const char* message)
{
    if (!condition)
    {
        fatalError(message);
    }
}

// BUGBUG rename to apiCallError / systemCallError?
void report_and_exit(const char* msg) 
{
    perror(msg);
    exit(-1); /* EXIT_FAILURE */
}

// Copies max possible number of bytes  to dest from (src + offset) and reports how many it was. 
int fillBuffer(char* dest, int destSize, const char* src, int srcOffset, int srcSize)
{
    int bytesToCopy = MIN(srcSize - srcOffset, destSize);
    memcpy(dest, src + srcOffset, bytesToCopy);
    return bytesToCopy;
}

 const char* msg_as_string(int msg_type)
 {
    switch (msg_type)
    {
    case TINYMSG_START_TRANSMISSION: 
        return "TINYMSG_START_TRANSMISSION";
    case TINYMSG_READY_TO_RECEIVE: 
        return "TINYMSG_READY_TO_RECEIVE";
    case TINYMSG_NOTIFY_DATA_SENT: 
        return "TINYMSG_NOTIFY_DATA_SENT";
    case TINYMSG_SERVER_IS_FULL:
        return "TINYMSG_SERVER_IS_FULL";
    default:
        return "UNKNOWN?!";
    }
}

bool isFree(TinyJob* job)
{
    if (job->id == 0)
    {
        ensure(
            job->incomingBytes == NULL &&
            job->outgoingBytes == NULL &&
            job->incomingSize == 0 &&
            job->outgoingSize == 0 && 
            job->offset == 0,
            "Active job can't have id == 0");

        return true;
    }

    return false;
}

// Free all buffers and clear it for re-use.
void reset(TinyJob* job)
{
    free(job->outgoingBytes);
    free(job->incomingBytes);
    memset(job, 0, sizeof(TinyJob));
}

// Returns pointer to the start of a given job's segment
char* segPtr(TinyState* ts, TinyJob* job)
{
    ensure(job->segment < ts->segmentCount, "setPtr: job's segment is invalid.");
    return ts->memptr + job->segment * ts->segmentSize;
}

//
// Message queue functions
//

int open_msg_queue()
{
    key_t key = ftok(QUEUE_FILENAME, PROJECT_ID);
    if (key < 0) report_and_exit("couldn't get key...");

    int qid = msgget(key, 0666 | IPC_CREAT);
    if (qid < 0) report_and_exit("couldn't get queue id...");

    return qid;
}

void delete_msg_queue(int qid)
{
    if (msgctl(qid, IPC_RMID, NULL) < 0)  /* NULL = 'no flags' */
      report_and_exit("trouble removing queue...");
}

//
// Shared memory functions
//

void create_segment(char* name, int size, int* out_fd, char** out_memptr)
{
    int fd = shm_open(name, O_RDWR | O_CREAT, SEGMENT_ACCESS_PERM);  /* empty to begin */
    if (fd < 0) report_and_exit("Can't get file descriptor...");

    ftruncate(fd, size); /* get the bytes */

    /* get a pointer to memory */
    void* memptr = mmap(
        NULL,       /* let system pick where to put segment */
        size    ,   /* how many bytes */
        PROT_READ | PROT_WRITE, /* access protections */
        MAP_SHARED, /* mapping visible to other processes */
        fd,         /* file descriptor */
        0);         /* offset: start at 1st byte */
    if ((void*) -1 == memptr) 
    {
        close(fd);
        report_and_exit("Can't access segment...");
    }

    memset(memptr, 0, size);

    *out_fd = fd;
    *out_memptr = memptr;
}

void open_segment(char* name, int size, int* out_fd, char** out_memptr)
{
    int fd = shm_open(name, O_RDWR, SEGMENT_ACCESS_PERM);  /* empty to begin */
    if (fd < 0) report_and_exit("Can't get file descriptor...");

    /* get a pointer to memory */
    void* memptr = mmap(
        NULL,       /* let system pick where to put segment */
        size    ,   /* how many bytes */
        PROT_READ | PROT_WRITE, /* access protections */
        MAP_SHARED, /* mapping visible to other processes */
        fd,         /* file descriptor */
        0);         /* offset: start at 1st byte */
    if ((void*) -1 == memptr) 
    {
        close(fd);
        report_and_exit("Can't access segment...");
    }

    *out_fd = fd;
    *out_memptr = memptr;
}

void close_segment(char* name,  int size, int fd, char* memptr)
{
    munmap(memptr, size);
    close(fd);
    shm_unlink(name);
}