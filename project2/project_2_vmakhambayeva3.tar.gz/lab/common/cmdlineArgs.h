#pragma once
#include <getopt.h>
#include <unistd.h>

typedef struct 
{
    int clientId;
    int segmentCount;
    int segmentSize;
    bool asyncMode;
    char* inputFileName;
    char* listFileName;

} CmdlineArgs;

void verifyArgsForServer(CmdlineArgs* parsedArgs)
{
    ensure(parsedArgs->segmentCount > 0, "Segment count is invalid.");
    ensure(parsedArgs->segmentSize > 0, "Segment size is invalid.");

     // Print for reference
    printf("Parameters: \n");
    printf("  - # of segments: %d\n", parsedArgs->segmentCount);
    printf("  - size of a segment: %d\n", parsedArgs->segmentSize);

    printf("\n");
}

void verifyArgsForClient(CmdlineArgs* parsedArgs)
{
    ensure(parsedArgs->segmentCount > 0, "Segment count is invalid.");
    ensure(parsedArgs->segmentSize > 0, "Segment size is invalid.");
    ensure(parsedArgs->inputFileName != NULL || parsedArgs->listFileName != NULL, "No input files.");

    // Print for reference
    printf("Parameters: \n");
    printf("  - client id: %d\n", parsedArgs->clientId);
    printf("  - # of segments: %d\n", parsedArgs->segmentCount);
    printf("  - size of a segment: %d\n", parsedArgs->segmentSize);
    printf("  - mode: %s\n", parsedArgs->asyncMode? "async" : "sync");
    if (parsedArgs->inputFileName != NULL)
    {
        printf("  - input file: %s\n", parsedArgs->inputFileName);
    }
    else
    {
        printf("  - list of input files: %s\n", parsedArgs->listFileName);
    }

    printf("\n");
}

bool isAsyncMode(const char* arg)
{    
    if (!strcmp("async", arg))
    {
        return true;
    }
    
    if (!strcmp("sync", arg))
    {
        return false;
    }

    fatalError("Can't parse async/sync mode argument");
    return false;
}

// Return copy of the string in arg if it points to an existing file.
char* parseFilename(const char* arg)
{
    char* result = NULL;
    int len = strlen(arg);
    if (len > 0)
    {
        result = malloc(len + 1);
        strcpy(result, arg);
    }
    else
    {
        printf("FileName '%s' is invalid.\n", arg);
    }

    return result;
}

//
// TODO: print this out on parse errors.
// Supported things:
//  -c, --client_id <num>- should be unique between all active clients.
//  -n, --n_sms <num> - number of shared segments.
//  -s, --sms_size <num> - size of a single segment in bytes.
//  -m, --mode sync|async - mode of operation.
//  -f, --file filename - single file to be compressed.
//  -F, --files filename - file which contains list of files to be compressed.
//
void parseCmdlineArgs(int argc, char* argv[], CmdlineArgs* parsedArgs)
{
    printf("Current folder: %s\n", argv[0]);

    memset(parsedArgs, 0, sizeof(CmdlineArgs));

    static struct option options[] = {
        {"client_id", required_argument, 0,  'c' },
        {"n_sms",  required_argument, 0,  'n' },
        {"sms_size",  required_argument,  0,  's' },
        {"mode",  required_argument, 0,  'm' },
        {"file",  required_argument, 0,  'f' },
        {"files",  required_argument, 0, 'F'},
        {0, 0, 0, 0 }
    };

    int c; 
    while (1)
    {
        int optionIndex = 0;
        c = getopt_long(argc, argv, "c:n:s:t:f:F:", options, &optionIndex);
        if (c == -1)
        {
            break;
        }

        switch (c)
        {
            case 'c': parsedArgs->clientId = atoi(optarg); break;
            case 'n': parsedArgs->segmentCount = atoi(optarg); break;
            case 's': parsedArgs->segmentSize = atoi(optarg); break;
            case 'm': parsedArgs->asyncMode = isAsyncMode(optarg); break;
            case 'f': parsedArgs->inputFileName = parseFilename(optarg); break;
            case 'F': parsedArgs->listFileName = parseFilename(optarg); break;

            default:
                printf("?? getopt returned character code 0%o ??\n", c);
                fatalError("Can't parse cmdline arguments.\n");
        }
    }
}