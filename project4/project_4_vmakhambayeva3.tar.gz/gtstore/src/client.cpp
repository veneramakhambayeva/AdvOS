#include "gtstore.hpp"

#include <xmlrpc-c/base.hpp>
#include <xmlrpc-c/registry.hpp>
#include <xmlrpc-c/client_simple.hpp>

void GTStoreClient::init(int id, string ip, uint32_t port) {

		cout << "Inside GTStoreClient::init() for client " << id << "\n";
		client_id = id;
		
		manager_url = "http://";
		manager_url += ip + ":" + to_string(port) + "/RPC2";
		_prefix = "[client] ";

}

val_t GTStoreClient::get(string key) {
	cout << "Inside GTStoreClient::get() for client: " << client_id << " key: " << key << "\n";
	val_t value;
	// Get the value!	
	if (key.empty())
	{
		cout << "key or value is empty should set it" << endl;
		return val_t();
	}

	if (key.size() > MAX_KEY_BYTE_PER_REQUEST)
		return val_t();

	value = Get(manager_url, key);	
	return value;
}

bool GTStoreClient::put(string key, val_t value) {

	if (key.empty() || value.empty())
	{
		cout << "key or value is empty should set it" << endl;
		return false;
	}

	if (key.size() > MAX_KEY_BYTE_PER_REQUEST)
		return false;

	auto value_size(0);

	for (auto i = 0u; i < value.size(); ++i)
		value_size += value[i].size();

	if (value_size > MAX_VALUE_BYTE_PER_REQUEST)
		return false;

	string print_value = "";
	for (uint i = 0; i < value.size(); i++) {
		print_value += value[i] + " ";
	}

	cout << "Inside GTStoreClient::put() for client: " << client_id << " key: " << key << " value: " << print_value << "\n";
	// Put the value!	
	return Put(manager_url, key, value);
}

void GTStoreClient::finalize() {

		cout << "Inside GTStoreClient::finalize() for client " << client_id << "\n";
}
