#ifndef GTSTORE
#define GTSTORE

#include <string>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <vector>
#include <map>
#include <unistd.h>
#include <sys/wait.h>
#include <mutex>
#include <cmath>
#include <cstring>
#include <climits>
#include <thread>
#include <list>
#include <xmlrpc-c/registry.hpp>
#include <xmlrpc-c/server_abyss.hpp>
#include <xmlrpc-c/client_simple.hpp>

#define MAX_KEY_BYTE_PER_REQUEST 20
#define MAX_VALUE_BYTE_PER_REQUEST 1000

using namespace std;

typedef vector<string> val_t;



#define METHOD_GET "get" 
#define METHOD_PUT "put" 
#define METHOD_GET_REPLICA "get_replica" 
#define METHOD_PUT_REPLICA "put_replica" 
#define METHOD_JOIN "join" 
#define METHOD_LEAVE "leave" 
#define METHOD_CHANGE_LEFT_NODE "change_left_node" 
#define METHOD_CHANGE_RIGHT_NODE "change_right_node" 
#define METHOD_HEARTBEAT "heart_beat" 

class INodeServer {
public:
	virtual ~INodeServer()= default;
	virtual bool Put(const string& key, const vector<string>& values) = 0; 
	virtual vector<string> Get(const string& key) = 0; 
	virtual void Run(uint32_t port) = 0;
};


class INodeClient {
public:
	virtual ~INodeClient() = default;
	virtual bool Put(const string& url, const string& key, const vector<string>& values) = 0; 
	virtual vector<string> Get(const string& url, const string& key) = 0; 
};


//---------------------------------- XMLRPC methods definition

class GetMethod : public xmlrpc_c::method {
private:
	
	INodeServer* _handler_ptr; 

public:
	GetMethod(INodeServer* handler_ptr) :_handler_ptr(handler_ptr) {}

	void execute(xmlrpc_c::paramList const& paramList, xmlrpc_c::value* const  resultP) {
		try {
			
			auto key = paramList.getString(0); 

			cout << "get value of key " << key << endl;

			paramList.verifyEnd(1);

			vector<xmlrpc_c::value> values;

			
			auto internal_values = _handler_ptr->Get(key); 

			
			for (auto i = 0u; i < internal_values.size(); ++i)
				values.push_back(xmlrpc_c::value_string(internal_values[i]));

			*resultP = xmlrpc_c::value_array(values);
		}
		catch (...) {
		}		
	}
};


class PutMethod : public xmlrpc_c::method {
private:
	
	INodeServer* _handler_ptr; 

public:
	PutMethod(INodeServer* handler_ptr) :_handler_ptr(handler_ptr) {}

	void execute(xmlrpc_c::paramList const& paramList, xmlrpc_c::value* const resultP) override
	{
		
		auto key = paramList.getString(0); 		

		
		vector<string> values;
		for (auto i = 1u; i < paramList.size(); ++i)
			values.push_back(paramList.getString(i));

		paramList.verifyEnd(paramList.size());

		
		auto result = _handler_ptr->Put(key, values);

		*resultP = xmlrpc_c::value_boolean(result);
	}
};


//------------------------------------------------------------
///
class BaseNode {
protected:
	
	mutex _locker;
	string _prefix;

public:
	virtual ~BaseNode() = default;

	bool CallMethod(const string& url, const string& method, const xmlrpc_c::paramList& params, xmlrpc_c::value* val) {
		try {			
			xmlrpc_c::clientSimple client;
			client.call(url, method, params, val);
			return true;
		}
		catch (exception ex) {
			cout << _prefix << "error on call method " << method << " error " << ex.what() << endl;
		}
		catch (...) {
			cout << _prefix << "error on call method " << method << endl;
		}
		return false;
	}

	bool CallMethod(const string& url, const string& method, xmlrpc_c::value* val) {
		try {
			xmlrpc_c::clientSimple client;
			client.call(url, method, val);
			return true;
		}
		catch (exception ex) {
			cout << _prefix << "error on call method " << method << " error " << ex.what() << endl;
		}
		catch (...) {
			cout << _prefix << "error on call method " << method << endl;
		}
		return false;
	}
};


class NodeClient: public virtual BaseNode, public INodeClient {
public:
	virtual ~NodeClient() = default;
		
	bool Put(const string& url, const string& key, const vector<string>& values) override {		
		xmlrpc_c::paramList params;
		xmlrpc_c::value val;

		params.addc(key);
		for (auto i = 0u; i < values.size(); ++i)
			params.addc(values[i]);

		cout << _prefix << "put value with key " << key << " to node " << url << endl;

		
		if(!CallMethod(url, METHOD_PUT, params, &val))
			return false;

		return  xmlrpc_c::value_boolean(val).cvalue();		
	}

	
	vector<string> Get(const string& url, const string& key) override {				
		xmlrpc_c::paramList params;
		xmlrpc_c::value val;

		vector<string> values;

		params.addc(key);

		cout << _prefix << "get value with key " << key << " from node " << url << endl;

		if (!CallMethod(url, METHOD_GET, params, &val)) {
			cout << _prefix << "Get method return false" << endl;
			return values;
		}
		
		auto value_array = xmlrpc_c::value_array(val).cvalue();

		for (auto i = 0u; i < value_array.size(); ++i)
			values.push_back(xmlrpc_c::value_string(value_array[i]).cvalue());

		string response;

		for (auto it : values)
			response += it + ";";

		cout << _prefix << "server response: " << response << endl;

		return values;
	}
};


class NodeServer: public virtual BaseNode, public INodeServer {
protected:
	
	vector<pair<string, xmlrpc_c::methodPtr>> _serverMethods;
	xmlrpc_c::registry _methodsRegistry;	

public:
	
	virtual void init() {		
		_methodsRegistry.addMethod(METHOD_GET, new GetMethod(this));
		_methodsRegistry.addMethod(METHOD_PUT, new PutMethod(this));
	}

	
	void Run(uint32_t port) override {
		xmlrpc_c::registry methodsRegistry;

		for (auto method : _serverMethods)
			methodsRegistry.addMethod(method.first, method.second);		

		xmlrpc_c::serverAbyss myAbyssServer(_methodsRegistry, port);

		cout << _prefix << "Start node service at port " << port << endl;
		myAbyssServer.run();
	}
};

class GTStoreClient: public NodeClient {
private:
	int client_id;
	val_t value;
	string manager_url;
public:
	
	void init(int id, string ip, uint32_t port);
	void finalize();
	val_t get(string key);
	bool put(string key, val_t value);
};

class GTStoreManager {
private:
	shared_ptr<INodeServer> _managerServer;
public:
	void init();
};

class GTStoreStorage {
private:
	shared_ptr<INodeServer> _storageServer;
public:
	void init();
};




#endif
