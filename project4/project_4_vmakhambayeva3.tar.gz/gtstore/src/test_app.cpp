#include "gtstore.hpp"
#include <signal.h>
#include <sstream>

#define PASS "\033[32;1m PASS \033[0m\n"
#define FAIL "\033[31;1m FAIL \033[0m\n"

void single_set_get(int client_id, vector<string> value) {
		cout << "Testing single set-get for GTStore by client " << client_id << ".\n";

		GTStoreClient client;
		client.init(client_id, "127.0.0.1", 8080);

		string key = to_string(client_id);		

		client.put(key, value);
		auto result_value = client.get(key);
		

		bool equal(true);
		if (value.size() != result_value.size()) {
			equal = false;
			cout << "value size mismatch" << endl;
		}
		else
			for (auto i = 0u; i < result_value.size(); ++i)
				if (value[i] != result_value[i])
				{
					equal = false;
					cout << "value mismatch" << endl;
				}

		if (equal)
			cout << PASS;
		else
			cout << FAIL;


		client.finalize();
}

void single_set(int client_id, vector<string> value) {
	cout << "Testing single set for GTStore by client " << client_id << ".\n";

	GTStoreClient client;
	client.init(client_id, "127.0.0.1", 8080);

	string key = to_string(client_id);

	client.put(key, value);	

	client.finalize();
}

void single_get(int client_id, vector<string> original_value) {
	cout << "Testing single get for GTStore by client " << client_id << ".\n";

	GTStoreClient client;
	client.init(client_id, "127.0.0.1", 8080);

	string key = to_string(client_id);

	auto result_value = client.get(key);
	cout << "value returned of " << result_value.size() << endl;

	bool equal(true);
	if (original_value.size() != result_value.size()) {
		equal = false;
		cout << "value size mismatch" << endl;
	}
	else
		for (auto i = 0u; i < result_value.size(); ++i)
			if (original_value[i] != result_value[i])
			{
				equal = false;
				cout << "value mismatch" << endl;
			}

	if (equal)
		cout << PASS;
	else
		cout << FAIL;


	client.finalize();
}

vector<string> split(const string &s, char delim) {
	vector<string> elems;
	stringstream ss;
	ss.str(s);

	std::string item;
	while (std::getline(ss, item, delim)) {
		elems.push_back(item);
	}
	return elems;
}

int main(int argc, char **argv) {
	string test = string(argv[1]);
	int client_id = atoi(argv[2]);

	vector<string> value;

	if (argc > 3)
		value = split(argv[3], ';');
	else
		value = { "test_01","test_02" ,"test_02" };

	string test1 = "single_set_get";
	if (string(argv[1]) == test1) {
		single_set_get(client_id,value);
	}

	string test2 = "single_get";
	if (string(argv[1]) == test2) {
		single_get(client_id,value);		
	}

	string test3 = "single_set";
	if (string(argv[1]) == test3) {
		single_set(client_id, value);
	}
}
