#include "gtstore.hpp"

#include <sstream>
#include <algorithm>
#include <fstream>


#define VIRTUAL_NODE_COUNT 10



size_t getHash(string key) {
	vector<uint8_t> sha1_hash(20, 0);

	auto hash = std::hash<std::string>{}(key);
	
	return hash;
}


uint32_t getToken(size_t hash) {
	uint32_t mod = pow(2.0, 32) - 1;
	uint64_t hash_sum(0);

	if (sizeof(hash) == 8) {
		hash_sum += (hash >> 16);
		hash_sum += (hash & 0x00000000FFFFFFFF);
	}
	else {
		hash_sum = hash;
	}

	return (uint32_t)(hash_sum % mod);
}


class IManager {
public:
	virtual ~IManager() = default;
	
	virtual uint32_t JoinNode(const string& ip, const string& port) = 0;
	
	virtual void LeaveNode(uint32_t token) = 0;
};


class JoinMethod : public xmlrpc_c::method {
private:
	IManager* _handler_ptr;

public:
	JoinMethod(IManager* handler_ptr) :_handler_ptr(handler_ptr) {
	}

	void execute(xmlrpc_c::paramList const& paramList, xmlrpc_c::value* const  resultP) override {
		cout << "<********************** CALL JOIN METHOD **************************>" << endl;
		
		auto ip = paramList.getString(0);
		auto port = paramList.getString(1);					

		
		auto token = _handler_ptr->JoinNode(ip, port);

		cout << "[manager] server token is " << token << endl;

		
		*resultP = xmlrpc_c::value_string(to_string(token));		
		cout << "<********************* END OF CALL JOIN METHOD ************************>" << endl;
	}
};


class LeaveMethod : public xmlrpc_c::method {
private:
	IManager* _handler_ptr;

public:
	LeaveMethod(IManager* handler_ptr) :_handler_ptr(handler_ptr) {
	}

	void execute(xmlrpc_c::paramList const& paramList, xmlrpc_c::value* const  resultP) override {
		cout << "<********************** CALL LEAVE METHOD **************************>" << endl;
		
		string str_token = paramList.getString(0);
		auto token = static_cast<uint32_t>(std::stoul(str_token));
		
		_handler_ptr->LeaveNode(token);
		cout << "<**************************** CALL END *****************************>" << endl;
	}
};


class ManagerImpl: public NodeServer, public NodeClient, public IManager {
protected:
	
	vector<pair<uint32_t, string>> _real_node_index;
	
	vector<pair<uint32_t, string>> _virtual_node_index;
	
	map<uint32_t, string> _token_to_id_index;
	
	thread _nodeCheckingThread;
	
	bool _isNodeCheckingStop;


	
	string FindNearestNode(uint64_t token) {
		if (_virtual_node_index.size() == 0) return "";

		for (auto it = _virtual_node_index.begin(); it!=_virtual_node_index.end(); ++it) {
			if (it->first >= token )
				return it->second;
		}
		
		return _virtual_node_index[_virtual_node_index.size() - 1].second;
	}

	
	string GetStorageNode(string key) {
		_locker.lock();

		auto token = getToken(getHash(key));

		cout << "[manager] token " << token << " for key " << key << endl;

		auto url = FindNearestNode(token);

		_locker.unlock();

		return url;
	}

	
	void ChangeLeftNode(string url_node, string url_left_node) {
		xmlrpc_c::paramList params;
		xmlrpc_c::value val;		

		params.addc(url_left_node);

		cout << "[manager] change left node at node " << url_node << endl;

		CallMethod(url_node, METHOD_CHANGE_LEFT_NODE, params, &val);
	}

	
	void ChangeRightNode(string url_node, string url_right_node) {
		xmlrpc_c::paramList params;
		xmlrpc_c::value val;

		params.addc(url_right_node);

		cout << "[manager] change right node at node " << url_node << endl;

		CallMethod(url_node, METHOD_CHANGE_RIGHT_NODE, params, &val);		
	}

public:
	ManagerImpl() :_isNodeCheckingStop(false) {
		_nodeCheckingThread = thread(&ManagerImpl::NodeCheckingLoop, this);
		_prefix = "[manager] ";
	}

	~ManagerImpl() {
		
		_isNodeCheckingStop = true;
		_nodeCheckingThread.join();		
	}

	void init() override {
		NodeServer::init();
		
		_methodsRegistry.addMethod(METHOD_JOIN, new JoinMethod(this));
		_methodsRegistry.addMethod(METHOD_LEAVE, new LeaveMethod(this));
	}	

	
	void NodeCheckingLoop() {
		while (!_isNodeCheckingStop) {
			cout << "[manager] checking " << _real_node_index.size() <<  " nodes ..." << endl;
			sleep(5);

			
			vector<uint32_t> tokensToLeave;

			_locker.lock();			
			for (auto i = 0u; i < _real_node_index.size(); ++i) {
				auto node = _real_node_index[i];
				
				if (!HeartBeat(node.second)) {
					tokensToLeave.push_back(node.first);					
					cout << "[manager] remove node " << node.first << endl;
				}
			}
			_locker.unlock();

			for (auto i = 0u; i < tokensToLeave.size(); ++i)
				LeaveNode(tokensToLeave[i]);
		}
	}

	
	bool Put(const string& key, const vector<string>& values) override {
		
		auto url = GetStorageNode(key);
		
		
		auto result = NodeClient::Put(url, key, values);
		return result;
	}

	
	vector<string> Get(const string& key) override {
		
		auto url = GetStorageNode(key);		

		
		return  NodeClient::Get(url, key);
	}

	
	uint32_t AddRealNode(string id, string url) {
		_locker.lock();

		
		auto token = getToken(getHash(id));

		
		_token_to_id_index[token] = id;

		if (_real_node_index.empty()) {
			_real_node_index.emplace_back(token, url);
			_locker.unlock();
			return token;
		}

		string left_url;
		string right_url;

		
		for (auto it = _real_node_index.begin(); it != _real_node_index.end(); ++it) {
			if (it->first > token) {
				if (it == _real_node_index.begin())
					left_url = _real_node_index.rbegin()->second;
				else
					left_url = (it - 1)->second;

				right_url = it->second;

				_real_node_index.insert(it, pair<uint32_t, string>(token, url));

				break;
			}
		}

		if (left_url.empty() && right_url.empty())
		{
			left_url = _real_node_index.rbegin()->second;
			right_url = _real_node_index.begin()->second;
			_real_node_index.push_back(pair<uint32_t, string>(token, url));
		}
		
		ChangeRightNode(left_url, url);
		ChangeLeftNode(right_url, url);
		ChangeRightNode(url, right_url);
		ChangeLeftNode(url, left_url);

		_locker.unlock();

		return token;
	}

	
	void AddVirtualNode(uint32_t token, string url) {
		_locker.lock();

		if (_virtual_node_index.empty())
			_virtual_node_index.emplace_back(token, url);

		
		for (auto it = _virtual_node_index.begin(); it != _virtual_node_index.end(); ++it) {
			if (it->first > token) {
				_virtual_node_index.insert(it, pair<uint32_t, string>(token, url));
				_locker.unlock();				
				return;
			}
		}

		_virtual_node_index.push_back(pair<uint32_t, string>(token, url));		
		_locker.unlock();
	}

	
	void RemoveRealNode(string id) {
		_locker.lock();

		string left_url;
		string right_url;

		auto token = getToken(getHash(id));

		
		for (auto it=_real_node_index.begin();it!=_real_node_index.end();++it) {
			if (it->first == token) {
				if(it == _real_node_index.begin())
					left_url = _real_node_index.rbegin()->second;
				else
					left_url = (it - 1)->second;

				if (it == (_real_node_index.end() - 1))
					right_url = _real_node_index.begin()->second;
				else
					right_url = (it + 1)->second;				

				_real_node_index.erase(it);
				cout << "[manager] erase real node " << token << endl;				

				
				ChangeRightNode(left_url, right_url);
				ChangeLeftNode(right_url, left_url);

				break;
			}
		}

		cout << "[manager] erase id from index " << _token_to_id_index.size() << endl;
		
		auto it = _token_to_id_index.find(token);
		_token_to_id_index.erase(it);		

		_locker.unlock();
	}

	
	void RemoveVirtualNode(uint32_t token) {
		_locker.lock();

		for (auto it = _virtual_node_index.begin(); it != _virtual_node_index.end(); ++it) {
			if (it->first == token) {
				_virtual_node_index.erase(it);
				cout << "[manager] erase virtual node " << token << endl;
				break;
			}
		}

		_locker.unlock();
	}

	
	void LeaveNode(uint32_t token) override {		
		cout << "[manager] leave node with token " << token << endl;
		_locker.lock();
		if(_token_to_id_index.find(token) == _token_to_id_index.end()) {
			cout << "[manager] can't find id with token " << token << endl;
			_locker.unlock();
			return;
		}		

		auto node_id = _token_to_id_index[token];
		_locker.unlock();

		
		RemoveRealNode(node_id);

		
		for (auto r = 0; r < VIRTUAL_NODE_COUNT; ++r)
		{
			auto replica_token = getToken(getHash(node_id + "#" + to_string(r)));
			cout << "[manager] remove replica " << replica_token << endl;
			RemoveVirtualNode(replica_token);
		}
	}

	
	uint32_t JoinNode(const string& ip, const string& port) override {
		auto node_id = ip + ":" + port;

		
		auto url = string("http://") + node_id + "/RPC2";
		
		cout << "[manager] join storage node " << node_id << endl;		

		
		auto token = AddRealNode(node_id, url);		

		
		for (auto r = 0; r < VIRTUAL_NODE_COUNT; ++r)
		{
			auto replica_token = getToken(getHash(node_id + "#" + to_string(r)));
			cout << "[manager] add virtual node with token " << replica_token << endl;

			AddVirtualNode(replica_token, url);
		}
		return token;
	}

	
	bool HeartBeat(string url) {
		try {
			xmlrpc_c::value val;

			CallMethod(url, METHOD_HEARTBEAT, &val);

			auto result = xmlrpc_c::value_boolean(val).cvalue();			
			return result;
		}
		catch (...) {
			cout << "[manager] error on heart beat" << endl;			
		}
		return false;
	}
};

void GTStoreManager::init() {
	
	cout << "Inside GTStoreManager::init()\n";

	try {
		ManagerImpl manager;
		cout << "Init manager service" << endl;
		manager.init();
		cout << "Run manager service" << endl;
		manager.Run(8080);					
	}
	catch (exception const& e) {
		cerr << "Something failed.  " << e.what() << endl;
	}

	cout << "Stop storage node service\n";
}

int main(int argc, char **argv) {

	GTStoreManager manager;
	manager.init();
	
}
