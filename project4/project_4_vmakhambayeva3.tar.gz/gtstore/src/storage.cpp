#include "gtstore.hpp"

#include <xmlrpc-c/base.hpp>
#include <xmlrpc-c/registry.hpp>
#include <xmlrpc-c/server_abyss.hpp>
#include <xmlrpc-c/client_simple.hpp>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>


#define REPLICA_COUNT 4


uint32_t GetFreePort() {
	uint32_t selected_port(0);

	while (!selected_port) {
		//generating a port number between 1024 and 65535
		uint16_t port_min(1024);
		srand(time(0));
		uint16_t portNoServer = rand() % 65536;

		if (portNoServer < port_min)
			portNoServer += port_min;

		sockaddr_in sock_addr;
		socklen_t len = sizeof(sock_addr);		

		auto sock = socket(AF_INET, SOCK_STREAM, 0);
		sock_addr.sin_family = AF_INET;
		sock_addr.sin_port = htons(portNoServer);
		sock_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

		if (bind(sock, (sockaddr*)&sock_addr, len) < 0) {
			cout << "[storage node] socket is busy" << endl;
			continue;
		}

		close(sock);
		selected_port = portNoServer;
	}
	return selected_port;
}


struct DataItem {
public:
	string key;
	vector<string> value;
	int64_t timestamp;
};


class HeartBeat : public xmlrpc_c::method {

public:	

	void execute(xmlrpc_c::paramList const& paramList, xmlrpc_c::value *   const  retvalP) {				
		*retvalP = xmlrpc_c::value_boolean(true);		
	}
};


class IStorageNode {
public:
	virtual ~IStorageNode() = default;
	
	virtual bool PutReplica(const DataItem& values, int replicaCounter) = 0;
	
	virtual DataItem GetReplica(const string& key, int replicaCounter) = 0;
	
	virtual void ChangeLeftNode(const string& url) = 0;
	
	virtual void ChangeRightNode(const string& url) = 0;
	virtual void Release() = 0;
};


class LeaveOnShutdown : public xmlrpc_c::serverAbyss::shutdown {
protected:
	IStorageNode* _handler_ptr;

public:
	LeaveOnShutdown(IStorageNode* handler_ptr, xmlrpc_c::serverAbyss * const severAbyssP) :xmlrpc_c::serverAbyss::shutdown(severAbyssP), _handler_ptr(handler_ptr){}

	void doit(std::string const& comment, void* const callInfo) const override {
		_handler_ptr->Release();
		xmlrpc_c::serverAbyss::shutdown::doit(comment, callInfo);
	}
};


class PutReplica : public xmlrpc_c::method {
private:
	IStorageNode* _handler_ptr;

public:
	PutReplica(IStorageNode* handler_ptr) :_handler_ptr(handler_ptr) {}

	void execute(xmlrpc_c::paramList const& paramList, xmlrpc_c::value* const resultP) override
	{		
		auto key = paramList.getString(0);
		
		auto replica_counter = paramList.getInt(1);
		auto timestamp = paramList.getI8(2);

		vector<string> values;
		for (auto i = 3u; i < paramList.size(); ++i)
			values.push_back(paramList.getString(i));
		
		paramList.verifyEnd(paramList.size());

		auto value = DataItem{key, values, timestamp };

		auto result = _handler_ptr->PutReplica(value, replica_counter);

		*resultP = xmlrpc_c::value_boolean(result);
	}
};


class GetReplica : public xmlrpc_c::method {
private:
	IStorageNode* _handler_ptr;

public:
	GetReplica(IStorageNode* handler_ptr) :_handler_ptr(handler_ptr) {}

	void execute(xmlrpc_c::paramList const& paramList, xmlrpc_c::value* const resultP) override
	{
		auto key = paramList.getString(0);
		
		auto replica_counter = paramList.getInt(1);

		vector<xmlrpc_c::value> values;

		paramList.verifyEnd(paramList.size());

		auto internal_values = _handler_ptr->GetReplica(key, replica_counter);

		values.push_back(xmlrpc_c::value_i8(internal_values.timestamp));

		for (auto it = internal_values.value.begin();it!= internal_values.value.end(); ++it)
			values.push_back(xmlrpc_c::value_string(*it));

		*resultP = xmlrpc_c::value_array(values);
	}
};


class ChangeLeftNode : public xmlrpc_c::method {
private:
	IStorageNode* _handler_ptr;

public:
	ChangeLeftNode(IStorageNode* handler_ptr) :_handler_ptr(handler_ptr) {}

	void execute(xmlrpc_c::paramList const& paramList, xmlrpc_c::value* const resultP) override
	{		
		auto url = paramList.getString(0);
		_handler_ptr->ChangeLeftNode(url);
		*resultP = xmlrpc_c::value_boolean(true);		
	}
};


class ChangeRightNode : public xmlrpc_c::method {
private:
	IStorageNode* _handler_ptr;

public:
	ChangeRightNode(IStorageNode* handler_ptr) :_handler_ptr(handler_ptr) {}

	void execute(xmlrpc_c::paramList const& paramList, xmlrpc_c::value* const resultP) override
	{		
		auto url = paramList.getString(0);
		_handler_ptr->ChangeRightNode(url);
		*resultP = xmlrpc_c::value_boolean(true);		
	}
};


class StorageNode: public NodeServer, public IStorageNode {
private:
	
	map<string, DataItem> _storage;
	
	map<string, DataItem> _storage_replica;
	
	string _token;

	string _ip;
	
	uint32_t _servicePort;

	
	string _leftNodeUrl;
	
	string _rightNodeUrl;


	thread _syncThread;
	mutex _syncLock;
	
	list<pair<DataItem,int>> _replicaQueue;
	bool _syncFlag;

	string _managerUrl;
	thread _asyncCall;
	

public:
	StorageNode(string ip, string port) {
		_managerUrl += "http://";
		_managerUrl += ip + ":" + port + "/RPC2";		
		_syncFlag = true;
		_prefix = "[storage node] ";
	}

	~StorageNode() {
		Release();
	}

	void Release() {
		_syncFlag = false;
		_syncLock.unlock();
		_syncThread.join();
	}

	
	void init() override {
		NodeServer::init();
		_methodsRegistry.addMethod(METHOD_HEARTBEAT, new HeartBeat());
		_methodsRegistry.addMethod(METHOD_CHANGE_LEFT_NODE, new ::ChangeLeftNode(this));
		_methodsRegistry.addMethod(METHOD_CHANGE_RIGHT_NODE, new ::ChangeRightNode(this));
		_methodsRegistry.addMethod(METHOD_GET_REPLICA, new ::GetReplica(this));
		_methodsRegistry.addMethod(METHOD_PUT_REPLICA, new ::PutReplica(this));
	}

	
	void Run(uint32_t port) override {
		_servicePort = port;
		_syncThread = thread(&StorageNode::Syncing, this);
		
		_asyncCall = thread(&StorageNode::ConnectToManager, this, _managerUrl, string("127.0.0.1"), to_string(port), this);

		xmlrpc_c::registry methodsRegistry;

		for (auto method : _serverMethods)
			methodsRegistry.addMethod(method.first, method.second);

		xmlrpc_c::serverAbyss myAbyssServer(_methodsRegistry, port);
		LeaveOnShutdown shutdown(this, &myAbyssServer);

		methodsRegistry.setShutdown(&shutdown);

		cout << "[storage node] Start node service on port " << port << endl;		
		myAbyssServer.run();
	}

	
	vector<string> Get(const string& key) override {
		_locker.lock();
		DataItem response;

				
		auto it = _storage.find(key);
		if (it != _storage.end()) {	
			response = it->second;
			_locker.unlock();
			return response.value;
		}

		
		
		_locker.unlock();

		response = GetReplica(key,REPLICA_COUNT);

		return response.value;
	}

	
	int64_t GetTimeStamp() const {
		auto tp = std::chrono::system_clock::now();
		auto dur = tp.time_since_epoch();
		return std::chrono::duration_cast<std::chrono::seconds>(dur).count();
	}

	
	DataItem GetReplica(const string& key, int replicaCounter) {
		DataItem response{ key, vector<string>(), -1 };
		cout << "[storage node " << _token << "] try to find replica hope #" << REPLICA_COUNT - replicaCounter;
		
		if (--replicaCounter < 0) return response;

		_locker.lock();		
		
		auto it = _storage_replica.find(key);
		if (it != _storage_replica.end()) {			
			response = it->second;
		}
		_locker.unlock();

		
		auto value_from_next_node = GetReplicaFromNextNode(key, replicaCounter);

		
		if (value_from_next_node.timestamp <= 0 || value_from_next_node.timestamp <= response.timestamp)
			return response;

		return value_from_next_node;
	}

	
	DataItem GetReplicaFromNextNode(const string& key, int replicaCounter) {
		DataItem response{ key, vector<string>(), -1 };

		if (_leftNodeUrl.empty()) return response;

		xmlrpc_c::paramList params;
		xmlrpc_c::value val;

		params.addc(key);
		params.addc(replicaCounter);
		
		if (!CallMethod(_leftNodeUrl, METHOD_GET_REPLICA, params, &val))
			return response;

		auto value_array = xmlrpc_c::value_array(val).cvalue();

		response.timestamp = xmlrpc_c::value_i8(value_array[0]);

		for (auto i = 1u; i < value_array.size(); ++i)
			response.value.push_back(xmlrpc_c::value_string(value_array[i]).cvalue());					

		return response;

	}
	
	bool Put(const string& key, const vector<string>& values) {
		_locker.lock();

		
		_storage[key] = DataItem{ key, values, GetTimeStamp() };
				
		_replicaQueue.push_back(pair<DataItem, int>(_storage[key], static_cast<int64_t>(REPLICA_COUNT)));
		_locker.unlock();

		
		_syncLock.unlock();		

		return true;
	}

	
	bool PutReplica(const DataItem& value, int replicaCounter) override {
		cout << "[storage node " << _token << "] add replica #" << REPLICA_COUNT - replicaCounter  << endl;
		string log;
		for (auto item : value.value)
			log += item + " ";
		cout << "[storage node " << _token << "] add replica on node " << _token << " for key " << value.key << " values " << log << endl;

		_locker.lock();
		
		_storage_replica[value.key] = value;
		
		if (--replicaCounter > 0)
			_replicaQueue.emplace_back(pair<DataItem,int>(value, replicaCounter));
		_locker.unlock();
		_syncLock.unlock();

		return true;
	}

	
	void PutReplicaOnNextNode(const DataItem& value, int replicaCounter) {
		if (_leftNodeUrl.empty()) return;
		
		xmlrpc_c::paramList params;
		xmlrpc_c::value val;

		params.addc(value.key);
		params.addc(replicaCounter);
		params.add(xmlrpc_c::value_i8(value.timestamp));

		for (auto i = 0u; i < value.value.size(); ++i)
			params.addc(value.value[i]);
		cout << "[storage node " << _token << "] call put on next node " <<  _leftNodeUrl << endl;
		CallMethod(_leftNodeUrl, METHOD_PUT_REPLICA, params, &val);
	}

	
	void Syncing() {
		while (_syncFlag) {
			_syncLock.lock();
			cout << "[storage node " << _token << "] syncing " << _replicaQueue.size() << " values in progress..." << endl;			
			if (!_replicaQueue.empty()) {

				 
				_locker.lock();
				auto keyForSync = *_replicaQueue.begin();
				_replicaQueue.pop_front();
				if (!_replicaQueue.empty())
					_syncLock.unlock();
				_locker.unlock();

				
				PutReplicaOnNextNode(keyForSync.first, keyForSync.second);				
			}
		}
	}

	
	void ChangeLeftNode(const string& url) override {
		_locker.lock();

		cout << "[storage node " << _token << "] change left node from \"" << _leftNodeUrl << "\" to \"" << url << "\"" << endl;

		string current_node("http://127.0.0.1:");
		current_node += to_string(_servicePort);
		current_node += "/RPC2";

		if (url == current_node) {			
			_locker.unlock();
			return;
		}

		
		_leftNodeUrl = url;
		for (auto it = _storage.begin(); it != _storage.end(); ++it) {			
			_replicaQueue.emplace_back(it->second, REPLICA_COUNT);
		}		
		_locker.unlock();

		_syncLock.unlock();
	}

	
	void ChangeRightNode(const string& url) override {
		_locker.lock();

		cout << "[storage node " << _token << "] change right node from \"" << _rightNodeUrl << "\" to \"" << url << "\""  << endl;

		string current_node("http://127.0.0.1:");
		current_node += to_string(_servicePort);
		current_node += "/RPC2";

		if(url == current_node) {			
			_locker.unlock();
			return;
		}

		_rightNodeUrl = url;		
		_locker.unlock();
	}

	
	void LeaveManager() {
		xmlrpc_c::paramList params;
		xmlrpc_c::value val;

		params.addc(GetToken());

		CallMethod(_managerUrl, METHOD_LEAVE, params, &val);		
	}

	string GetToken(){
		_locker.lock();
		auto token = _token;
		_locker.unlock();
		return token;
	}

	void SetToken(const string& token) {
		_locker.lock();
		_token = token;
		_prefix = "[storage node " + _token + "] ";
		_locker.unlock();
	}

	
	void ConnectToManager(string manager_url, string ip, string port, IStorageNode* node) {
		sleep(2);
		cout << "[storage node] run thread to connection to manager" << endl;

		xmlrpc_c::paramList params;
		xmlrpc_c::value val;

		params.addc(ip);
		params.addc(port);		

		cout << "[storage node] try connect..." << endl;
		CallMethod(manager_url, METHOD_JOIN, params, &val);		

		auto token = xmlrpc_c::value_string(val).cvalue();

		cout << "[storage node] none connected successfully node toke is " << token << endl;

		
		SetToken(token);
	}
};



void GTStoreStorage::init() {
	
	cout << "Inside GTStoreStorage::init()\n";

	try {
		auto port = GetFreePort();
		cout << "select port " << port << endl;
		StorageNode node("127.0.0.1", "8080");
		node.init();
		node.Run(port);
	}
	catch (exception const& e) {
		cerr << "Something failed.  " << e.what() << endl;
	}

	cout << "Stop storage node service\n";

	
}

int main(int argc, char **argv) {

	GTStoreStorage storage;
	storage.init();
	
}
