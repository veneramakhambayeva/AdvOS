#/bin/bash

make clean
make

# Launch the GTStore Manager
./bin/manager &
MANAGER_PID=$!

# Launch 5 GTStore Storage Nodes
./bin/storage &
STORAGE_NODE_1_PID=$!
sleep 5

./bin/storage &
STORAGE_NODE_2_PID=$!
sleep 5

./bin/storage &
STORAGE_NODE_3_PID=$!
sleep 5

./bin/storage &
STORAGE_NODE_4_PID=$!
sleep 5

./bin/storage &
STORAGE_NODE_5_PID=$!
sleep 5

# Launch the client testing app
# Usage: ./test_app <test> <client_id>
echo "|||||||||||||||||||||||||||||||||| Data Replication sample ||||||||||||||||||||||||||||||||||||||"

./bin/test_app single_set 1 "phone;phone_case"
sleep 15

echo "|||||||||||||||||||||||||||||||||| Data Partitioning sample ||||||||||||||||||||||||||||||||||||||"

./bin/test_app single_set 2 "phone;phone_case"
./bin/test_app single_set 3 "phone;phone_case"
sleep 15

echo "|||||||||||||||||||||||||||||||||| sample put get ||||||||||||||||||||||||||||||||||||||"

./bin/test_app single_set_get 1 "phone;phone_case;laptop;powerbank" &
./bin/test_app single_set_get 2 "phone;phone_case;laptop;powerbank" &
./bin/test_app single_set_get 3 "phone;phone_case;laptop;powerbank"
sleep 15

echo "|||||||||||||||||||||||||||||||||| Failure Handler sample ||||||||||||||||||||||||||||||||||||||"

kill $STORAGE_NODE_1_PID
kill $STORAGE_NODE_5_PID
sleep 15

echo "|||||||||||||||||||||||||||||||||| Data Consistency sample ||||||||||||||||||||||||||||||||||||||"

./bin/test_app single_get 1 "phone;phone_case;laptop;powerbank" &
./bin/test_app single_get 2 "phone;phone_case;laptop;powerbank" &
./bin/test_app single_get 3 "phone;phone_case;laptop;powerbank"
sleep 15

echo -------------------- start another one node ---------------------
./bin/storage &
STORAGE_NODE_5_PID=$!
sleep 15

echo ------------------ check values -----------------------
./bin/test_app single_set_get 1 "battery;lamp;book" &
./bin/test_app single_set_get 2 "battery;lamp;book" &
./bin/test_app single_set_get 3 "battery;lamp;book" 
sleep 15

kill $STORAGE_NODE_2_PID
kill $STORAGE_NODE_3_PID
kill $STORAGE_NODE_4_PID
kill $STORAGE_NODE_5_PID
kill $MANAGER_PID
sleep 5