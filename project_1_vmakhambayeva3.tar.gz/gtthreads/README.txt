1. Type 'make' to compile the GTThreads library 
2. Type 'make matrix' to compile the matrix program
3. ./bin/matrix to run the matrix program
4 Choose scheduler.
5. 'make clean'
