#include <stdio.h>
#include <unistd.h>
#include <linux/unistd.h>
#include <sys/syscall.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sched.h>
#include <signal.h>
#include <setjmp.h>
#include <errno.h>
#include <assert.h>
#include <math.h>
#include "gt_include.h"

#define GT_THREADS 1
#define ROWS 512
#define COLS ROWS
#define SIZE COLS

#define NUM_CPUS 4
#define NUM_GROUPS 16
#define PER_GROUP_COLS (SIZE/NUM_GROUPS)

#define NUM_THREADS 128
#define PER_THREAD_ROWS (SIZE/NUM_THREADS)
int sh_type;
int lb_type;

/* A[SIZE][SIZE] X B[SIZE][SIZE] = C[SIZE][SIZE]
 * Let T(g, t) be thread 't' in group 'g'. 
 * T(g, t) is responsible for multiplication : 
 * A(rows)[(t-1)*SIZE -> (t*SIZE - 1)] X B(cols)[(g-1)*SIZE -> (g*SIZE - 1)] */

typedef struct matrix
{
	int m[SIZE][SIZE];

	int rows;
	int cols;
	unsigned int reserved[2];
} matrix_t;


typedef struct __uthread_arg
{
	matrix_t *_A, *_B, *_C;
	unsigned int reserved0;
	unsigned int tid;
	unsigned int gid;
	int start_row; /* start_row -> (start_row + PER_THREAD_ROWS) */
	int start_col; /* start_col -> (start_col + PER_GROUP_COLS) */
	int m_dim; /* matrix size*/

}uthread_arg_t;

typedef struct uthread_perf_stats // performance of each thread. 
{
	float runtime_mean;
	float std_dev_total;
	float std_dev_run;
	float total_mean;
}uthread_perf_stats_t;

struct timeval tv1;

static void generate_matrix(matrix_t *mat, int val)
{

	int i,j;
	mat->rows = SIZE;
	mat->cols = SIZE;
	for(i = 0; i < mat->rows;i++)
		for( j = 0; j < mat->cols; j++ )
		{
			mat->m[i][j] = val;
		}
	return;
}

static void print_matrix(matrix_t *mat)
{
	int i, j;

	for(i=0;i<SIZE;i++)
	{
		for(j=0;j<SIZE;j++)
			printf(" %d ",mat->m[i][j]);
		printf("\n");
	}

	return;
}

extern int uthread_create(uthread_t *, void *, void *, uthread_group_t, int);

static void * uthread_mulmat(void *p)
{
	int i, j, k;
	int start_row, end_row;
	int start_col, end_col;
	unsigned int cpuid;
	struct timeval tv2;
	int m_dim; /* matrix size */
	int c; /* count of yeling*/

#define ptr ((uthread_arg_t *)p)

	i=0; j= 0; k=0;

	start_row = 0;
	end_row = ptr->m_dim;

/*#ifdef GT_GROUP_SPLIT
	start_col = ptr->start_col;
	end_col = (ptr->start_col + PER_THREAD_ROWS);
#else*/
	start_col = 0;
	end_col = ptr->m_dim;
	m_dim=end_col;
//#endif

#ifdef GT_THREADS
	cpuid = kthread_cpu_map[kthread_apic_id()]->cpuid;
	fprintf(stderr, "\nThread(id:%d, group:%d, cpu:%d) started",ptr->tid, ptr->gid, cpuid);
#else
	fprintf(stderr, "\nThread(id:%d, group:%d) started",ptr->tid, ptr->gid);
#endif

	for(i = start_row; i < end_row; i++)
		{for(j = start_col; j < end_col; j++)
			{for(k = 0; k < SIZE; k++)
				{//if (ptr->tid == 100 && sh_type==1 && c<2)
				//		 { 
				//		 	gt_yield();
				//		 	c++;
				//		 }
						 ptr->_C->m[i][j] += ptr->_A->m[i][k] * ptr->_B->m[k][j];}}}

#ifdef GT_THREADS
	gettimeofday(&tv2,NULL);
	fprintf(stderr, "\nThread(id:%d, group:%d, cpu:%d) finished (TIME : %lu s and %lu us)",
			ptr->tid, ptr->gid, cpuid, (tv2.tv_sec - tv1.tv_sec), (tv2.tv_usec - tv1.tv_usec));
#else
	gettimeofday(&tv2,NULL);
	fprintf(stderr, "\nThread(id:%d, group:%d) finished (TIME : %lu s and %lu us)",
			ptr->tid, ptr->gid, (tv2.tv_sec - tv1.tv_sec), (tv2.tv_usec - tv1.tv_usec));
#endif

#undef ptr
	return 0;
}

matrix_t A, B, C;

static void init_matrices()
{
	generate_matrix(&A, 1);
	generate_matrix(&B, 1);
	generate_matrix(&C, 0);

	return;
}


/*void parse_args(int argc, char* argv[])
{
	int inx;

	for(inx=0; inx<argc; inx++)
	{
		if(argv[inx][0]=='-')
		{
			if(!strcmp(&argv[inx][1], "lb"))
			{
				//TODO: add option of load balancing mechanism
				printf("enable load balancing\n");
			}
			else if(!strcmp(&argv[inx][1], "s"))
			{
				//TODO: add different types of scheduler
				inx++;
				if(!strcmp(&argv[inx][0], "0"))
				{
					printf("use priority scheduler\n");
				}
				else if(!strcmp(&argv[inx][0], "1"))
				{
					printf("use credit scheduler\n");
				}
			}
		}
	}

	return;
}*/



uthread_arg_t uargs[NUM_THREADS];
uthread_t utids[NUM_THREADS];

int main()
{
	uthread_arg_t *uarg;
	int inx;
	int gr=0;
	int th_num=0;
	int credit=25;
	int size=32;

	//parse_args(argc, argv);

	gtthread_app_init();

	init_matrices();

	gettimeofday(&tv1,NULL);

	printf("Choose your scheduler:\n(0) O(1) Priority Scheduler\n(1) Credit Scheduler\n");
        scanf("%d",&sh_type);
        printf ("%d",sh_type);
        if (sh_type==1)
        	{    printf("Choose lb:\n(0) no\n(1) yes\n");
        scanf("%d",&lb_type);
        printf ("%d",lb_type);}
  if (sh_type == 0)
    {
		for(size = 32; size <= 256; size *= 2)
		{		 
				for(inx=0; inx < 32; inx++)
				{	uarg = &uargs[th_num];
					uarg->_A = &A;
					uarg->_B = &B;
					uarg->_C = &C;
					uarg->tid = th_num;
					uarg->gid = (th_num % NUM_GROUPS);
					uarg->m_dim = size;
					uthread_create(&utids[th_num], uthread_mulmat, uarg, uarg->gid, 0);
					th_num+=1;}
				gr++;}}

	else if (sh_type == 1)
	{for(credit = 25; credit <= 100; credit += 25)
		{for(size = 32; size <= 256; size *= 2)
			{for(inx=0; inx < 8; inx++)
				{	uarg = &uargs[th_num];
					uarg->_A = &A;
					uarg->_B = &B;
					uarg->_C = &C;
					uarg->tid = th_num;
					uarg->gid = (th_num % NUM_GROUPS);
					uarg->m_dim = size;
					uthread_create(&utids[th_num], uthread_mulmat, uarg, uarg->gid, credit);
					th_num+=1;}
				gr++;}}}
	else 
		{	printf("wrong value");
			return(0);
		}
	/*for(inx=0; inx<NUM_THREADS; inx++)
	{
		uarg = &uargs[inx];
		uarg->_A = &A;
		uarg->_B = &B;
		uarg->_C = &C;

		uarg->tid = inx;

		uarg->gid = (inx % NUM_GROUPS);

		uarg->start_row = (inx * PER_THREAD_ROWS);
#ifdef GT_GROUP_SPLIT
		/* Wanted to split the columns by groups !!! */
		/*uarg->start_col = (uarg->gid * PER_GROUP_COLS);
#endif

		uthread_create(&utids[inx], uthread_mulmat, uarg, uarg->gid);
	}*/

	gtthread_app_exit();
	th_num=0;
	gr=0;
	int pointer=0;
	uthread_perf_stats_t *stats_t = (uthread_perf_stats_t *)calloc(16, sizeof(uthread_perf_stats_t)); 
	printf("------------------------------------------Timing-----------------------------------------------\n");
	credit=25;
 int i;
  for (credit=25; credit<=100; credit+=25)
	{
    int size=32;
		for(size=32; size<=256; size*=2)
		{
			th_num=pointer;
			for(i=0;i<8;i++)
			{
				assert(th_num==uthread_time[th_num]->id);
				stats_t[gr].runtime_mean += (uthread_time[th_num]->runtime.tv_sec*1000000 + uthread_time[th_num]->runtime.tv_usec);
				stats_t[gr].total_mean+= (uthread_time[th_num]->totaltime.tv_sec*1000000 + uthread_time[th_num]->totaltime.tv_usec);
				th_num++;	
			}
			stats_t[gr].runtime_mean /= 8;
			stats_t[gr].total_mean/=8;
			th_num=pointer;
			for (i=0;i<8;i++)
			{
				stats_t[gr].std_dev_run+=pow(((uthread_time[th_num]->runtime.tv_sec*1000000 + uthread_time[th_num]->runtime.tv_usec)-stats_t[gr].runtime_mean),2);
				stats_t[gr].std_dev_total+=pow(((uthread_time[th_num]->totaltime.tv_sec*1000000 + uthread_time[th_num]->totaltime.tv_usec)-stats_t[gr].total_mean),2);
				th_num++;
			}
			stats_t[gr].std_dev_run=sqrt(stats_t[gr].std_dev_run/8);
			stats_t[gr].std_dev_total=sqrt(stats_t[gr].std_dev_total/8);

			printf("Cr:%d 	Mat:%d 	 	SD(rt)%f  		SD(tt)%f  		M(rt)%f  		M(tt)%f\n", credit, size, stats_t[gr].std_dev_run, stats_t[gr].std_dev_total, stats_t[gr].runtime_mean, stats_t[gr].total_mean);
			gr++;
			pointer+=8;
		}
	}	

	// print_matrix(&C);
	// fprintf(stderr, "********************************");
	return(0);
}
