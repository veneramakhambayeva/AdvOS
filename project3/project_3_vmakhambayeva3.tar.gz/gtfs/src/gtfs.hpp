#ifndef GTFS
#define GTFS

#include <string>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <unistd.h>
#include <sys/wait.h>

#include <pthread.h>
#include <map>
#include <functional>
#include <list>
#include <memory>
#include <vector>

using namespace std;

#define PASS "\033[32;1m PASS \033[0m\n"
#define FAIL "\033[31;1m FAIL \033[0m\n"

// GTFileSystem basic data structures 

#define MAX_FILENAME_LEN 255
#define MAX_NUM_FILES_PER_DIR 1024

extern int do_verbose;

typedef uint64_t tid_t; //define type of transaction id

typedef struct write {
    string filename;
    int offset;
    int length;
    char *data;
    // TODO: Add any additional fields if necessary
    char* undo_data; //temp buffer for data recovery
    bool is_used = false;
    tid_t tid; //unique id of transaction
} write_t;

typedef struct file {
    string filename;
    int file_length;
    // TODO: Add any additional fields if necessary
    string log_filename; //path to log file
    string home_filename;  //path to real file which was opened
    char* mapped_data; //buffer for RVM
    bool is_used = false; 
    bool is_mapped = false;
    bool initialized = false;
    list<shared_ptr<write_t>> trans_queue; //queue of modifications
	vector<char> read_buffer; //buffer for read data
} file_t;

typedef map<string, shared_ptr<file_t>> filesdb_t;

typedef struct gtfs {
    string dirname;
    // TODO: Add any additional fields if necessary
    bool initialized = false;
    filesdb_t files_db; //array of opened files
} gtfs_t;

// GTFileSystem basic API calls

gtfs_t* gtfs_init(string directory, int verbose_flag);
int gtfs_clean(gtfs_t *gtfs);

file_t* gtfs_open_file(gtfs_t* gtfs, string filename, int file_length);
int gtfs_close_file(gtfs_t* gtfs, file_t* fl);
int gtfs_remove_file(gtfs_t* gtfs, file_t* fl);

char* gtfs_read_file(gtfs_t* gtfs, file_t* fl, int offset, int length);
write_t* gtfs_write_file(gtfs_t* gtfs, file_t* fl, int offset, int length, const char* data);
int gtfs_sync_write_file(write_t* write_id);
int gtfs_abort_write_file(write_t* write_id);

// BONUS: Implement below API calls to get bonus credits

int gtfs_clean_n_bytes(gtfs_t *gtfs, int bytes);
int gtfs_sync_write_file_n_bytes(write_t* write_id, int bytes);

// TODO: Add here any additional data structures or API calls
typedef map<const string, shared_ptr<gtfs>> gtfsdb_t;
extern gtfsdb_t g_gtfsdb; //array of initialized directories
extern pthread_mutex_t gtfs_lock;
extern uint64_t g_tid_counter; //counter of unique transaction's id
extern map<uint64_t, file_t*> g_trans_map; //array of transaction's id and corresponding file structure

#define GTFS_LOCK pthread_mutex_lock(&(gtfs_lock))
#define GTFS_UNLOCK pthread_mutex_unlock(&(gtfs_lock))
#define GTFS_INIT_LOCK pthread_mutex_init(&(gtfs_lock), nullptr)
#define GTFS_DESTROY_LOCK pthread_mutex_destroy(&(gtfs_lock))

bool gtfs_truncate_log(string home_file_name, string log_file_name);            

int gtfs_close_file_and_clean(file_t* fl);





#endif
