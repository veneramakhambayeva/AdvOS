#include "gtfs.hpp"
#include <sys/stat.h>
#include <fcntl.h>
#include <sstream>
#include <string.h>

#define VERBOSE_PRINT(verbose, str...) do { \
    if (verbose) cout << "VERBOSE: "<< __FILE__ << ":" << __LINE__ << " " << __func__ << "(): " << str; \
} while(0)

int do_verbose;

gtfsdb_t g_gtfsdb;
pthread_mutex_t gtfs_lock;
uint64_t g_tid_counter(1);
map<uint64_t, file_t*> g_trans_map;

gtfs_t* gtfs_init(string directory, int verbose_flag) {
    do_verbose = verbose_flag;
    shared_ptr<gtfs_t> gtfs(nullptr);
    VERBOSE_PRINT(do_verbose, "Initializing GTFileSystem inside directory " << directory << "\n");
    //TODO: Add any additional initializations and checks, and complete the functionality

	auto ret_code = GTFS_INIT_LOCK;
    GTFS_LOCK;
    if(ret_code != 0)
        VERBOSE_PRINT(do_verbose, "ERROR: on mutex init\n");

    //Try to find initialized gtfs for this directory   
    auto it = g_gtfsdb.find(directory);
    if (it != g_gtfsdb.end()) {
		VERBOSE_PRINT(do_verbose, "Found initialized gtfs instanse\n");
        gtfs = g_gtfsdb[directory];
        GTFS_UNLOCK;
        return gtfs.get();
    }

    struct stat st;

    //check if directory not exist
    if (stat(directory.c_str(), &st) == -1) {
        VERBOSE_PRINT(do_verbose, "create directory\n");
        if (mkdir(directory.c_str(), 0777) == -1){
            VERBOSE_PRINT(do_verbose, "ERROR: can't create directory!" << directory << "\n");
            GTFS_UNLOCK;
            return nullptr;
        }
    }

    gtfs = make_shared<gtfs_t>();
    gtfs->dirname = directory;
    gtfs->initialized = true;   

    VERBOSE_PRINT(do_verbose, "gtfs inited in " << gtfs->dirname << "\n");

    g_gtfsdb[directory] = gtfs;
    
	GTFS_UNLOCK;

    VERBOSE_PRINT(do_verbose, "Success\n"); //On success returns non NULL.
    return gtfs.get();
}

int gtfs_clean(gtfs_t *gtfs) {
    int ret = -1;
    if (gtfs) {
        VERBOSE_PRINT(do_verbose, "Cleaning up GTFileSystem inside directory " << gtfs->dirname << "\n");
    } else {
        VERBOSE_PRINT(do_verbose, "GTFileSystem does not exist\n");
        return ret;
    }
    //TODO: Add any additional initializations and checks, and complete the functionality
    
	GTFS_LOCK;	

    for(auto it_fs = gtfs->files_db.begin(); it_fs!=gtfs->files_db.end();++it_fs){
         gtfs_truncate_log(it_fs->second->home_filename, it_fs->second->log_filename);		
    }
	
	ret = 0;

	GTFS_UNLOCK;

    VERBOSE_PRINT(do_verbose, "Success\n"); //On success returns 0.
    return ret;
}

file_t* gtfs_open_file(gtfs_t* gtfs, string filename, int file_length) {
    shared_ptr<file_t> fl(nullptr);
    if (gtfs) {
        VERBOSE_PRINT(do_verbose, "Opening file " << filename << " inside directory " << gtfs->dirname << "\n");
    } else {
        VERBOSE_PRINT(do_verbose, "GTFileSystem does not exist\n");
        return nullptr;
    }
    //TODO: Add any additional initializations and checks, and complete the functionality

	GTFS_LOCK;

    auto it = gtfs->files_db.find(filename);
    if (it != gtfs->files_db.end()) {
        VERBOSE_PRINT(do_verbose, "WARNING: File is opened by another thread\n");
		GTFS_UNLOCK;
        return nullptr;
    }

    fl = make_shared<file_t>();

    stringstream name_builder;
    name_builder << gtfs->dirname;
    if (gtfs->dirname[gtfs->dirname.size() - 1] != '/')
        name_builder << "/";
    name_builder << filename;

    string home_file_name = name_builder.str();
    string log_file_name = name_builder.str() + ".log";    

    struct stat st;
    int fd = 0;

    bool home_file_exist = false;
    bool log_file_exist = false;

	fl->filename = filename;
    fl->file_length = file_length;
    fl->log_filename = log_file_name;    
    fl->home_filename = home_file_name;    
    fl->is_mapped = false;
    fl->is_used = false;	

    uint64_t file_size(0);

    if (stat(log_file_name.c_str(), &st) == 0) {
        log_file_exist = true;
    }

    VERBOSE_PRINT(do_verbose, "Open file " << fl->filename << " and log file " << fl->log_filename << "\n");

    if (log_file_exist) {
        VERBOSE_PRINT(do_verbose, "Log file exist,try to trucate log file\n");
        gtfs_truncate_log(home_file_name, log_file_name);
        home_file_exist = true;
    }

    if (stat(home_file_name.c_str(), &st) == 0) {
        home_file_exist = true;
    }

    if (home_file_exist) {
        fd = open(home_file_name.c_str(), O_RDWR);
        if (fd < 0) {
            VERBOSE_PRINT(do_verbose, "ERROR: can't open file\n");
			GTFS_UNLOCK;
            return nullptr;
        }

        file_size = lseek(fd, 0, SEEK_END);
        lseek(fd, 0, SEEK_SET);
        if(file_size >file_length) {
            close(fd);
            VERBOSE_PRINT(do_verbose, "WARNING: exist file size is more than file_length\n");
			GTFS_UNLOCK;
            return nullptr;
        }

        fl->mapped_data = (char*)malloc(file_length);
        if (fl->mapped_data == nullptr) {
            close(fd);
            VERBOSE_PRINT(do_verbose, "ERROR: can't allocate memory\n");
			GTFS_UNLOCK;
            return nullptr;
        }
        memset(fl->mapped_data,0,file_length);
        read(fd, fl->mapped_data, file_size);        
    }
    else {        
        fd = creat(home_file_name.c_str(), 00644);

        VERBOSE_PRINT(do_verbose, "created home file " << home_file_name << "\n");

        if (fd < 0) {
            VERBOSE_PRINT(do_verbose, "ERROR: can't create persistent file\n");
			GTFS_UNLOCK;
            return nullptr;
        }

        fl->mapped_data = (char*)malloc(file_length);
        if (fl->mapped_data == nullptr) {
            close(fd);
            VERBOSE_PRINT(do_verbose, "ERROR: can't allocate memory\n");
			GTFS_UNLOCK;
            return nullptr;
        }
        memset(fl->mapped_data,0,file_length);
    }

    fl->is_mapped = true;
    fl->is_used = true;


    if(ftruncate(fd, file_length) != 0)
    {
        VERBOSE_PRINT(do_verbose, "ERROR: can't truncate home file\n");
    }

    close(fd);
    fl->trans_queue.clear();
    fl->initialized = true;
    gtfs->files_db[filename] = fl;

	GTFS_UNLOCK;

    VERBOSE_PRINT(do_verbose, "Success\n"); //On success returns non NULL.
    return fl.get();
}

int gtfs_close_file(gtfs_t* gtfs, file_t* fl) {
    int ret = -1;
    if (gtfs && fl) {
        VERBOSE_PRINT(do_verbose, "Closing file " << fl->filename << " inside directory " << gtfs->dirname << "\n");
    } else {
        VERBOSE_PRINT(do_verbose, "GTFileSystem or file does not exist\n");
        return ret;
    }
    //TODO: Add any additional initializations and checks, and complete the functionality
	GTFS_LOCK;

	gtfs_close_file_and_clean(fl);

    auto it = gtfs->files_db.find(fl->filename);
    if (it != gtfs->files_db.end()) {        
        gtfs->files_db.erase(it);
    }

	GTFS_UNLOCK;

	ret = 0;

    VERBOSE_PRINT(do_verbose, "Success\n"); //On success returns 0.
    return ret;
}

int gtfs_remove_file(gtfs_t* gtfs, file_t* fl) {
    int ret = -1;
    if (gtfs && fl) {
        VERBOSE_PRINT(do_verbose, "Removing file " << fl->filename << " inside directory " << gtfs->dirname << "\n");
    } else {
        VERBOSE_PRINT(do_verbose, "GTFileSystem or file does not exist\n");
        return ret;
    }
    //TODO: Add any additional initializations and checks, and complete the functionality
	GTFS_LOCK;
    if (!fl->is_used) {
        remove(fl->log_filename.c_str());
        remove(fl->home_filename.c_str());
        ret = 0;
    }
    else {
        VERBOSE_PRINT(do_verbose, "WARNING: File in use\n");
		GTFS_UNLOCK;
        return -1;
    }
	GTFS_UNLOCK;

    VERBOSE_PRINT(do_verbose, "Success\n"); //On success returns 0.
    return ret;
}

char* gtfs_read_file(gtfs_t* gtfs, file_t* fl, int offset, int length) {
    char* ret_data = NULL;
    if (gtfs && fl) {
        VERBOSE_PRINT(do_verbose, "Reading " << length << " bytes starting from offset " << offset << " inside file " << fl->filename << "\n");
    } else {
        VERBOSE_PRINT(do_verbose, "GTFileSystem or file does not exist\n");
        return NULL;
    }
    //TODO: Add any additional initializations and checks, and complete the functionality
	GTFS_LOCK;

    if(offset + length>fl->file_length) {
        VERBOSE_PRINT(do_verbose, "ERROR: out of memory\n");
        return nullptr;
    }

	fl->read_buffer.resize(length,0);
    
    if(fl->initialized && fl->is_used) {
	   memcpy(fl->read_buffer.data(),fl->mapped_data + offset,length);
       VERBOSE_PRINT(do_verbose, "content of read buffer: \"" << fl->read_buffer.data() << "\"\n");
	   GTFS_UNLOCK;
       return fl->read_buffer.data();
    }

	GTFS_UNLOCK;

    VERBOSE_PRINT(do_verbose, "Success\n"); //On success returns pointer to data read.
    return ret_data;
}

write_t* gtfs_write_file(gtfs_t* gtfs, file_t* fl, int offset, int length, const char* data) {
    shared_ptr<write_t> write_id(nullptr);
    if (gtfs && fl) {
        VERBOSE_PRINT(do_verbose, "Writting " << length << " bytes starting from offset " << offset << " inside file " << fl->filename << "\n");
    } else {
        VERBOSE_PRINT(do_verbose, "GTFileSystem or file does not exist\n");
        return NULL;
    }
    //TODO: Add any additional initializations and checks, and complete the functionality

	GTFS_LOCK;

    VERBOSE_PRINT(do_verbose, "write data size "<< length << " at offset " << offset << "with  file size " << fl->file_length << "\n");

    if (offset + length > fl->file_length) {
        VERBOSE_PRINT(do_verbose, "ERROR: write out of memory\n");
		GTFS_UNLOCK;
        return nullptr;
    }

    auto tid = g_tid_counter++;

    write_id = make_shared<write_t>();
    write_id->filename = fl->filename;
    write_id->offset = offset;
    write_id->length = length;
    write_id->data = (char*)fl->mapped_data;
    write_id->is_used = true;
    write_id->undo_data = (char*)malloc(length);
    write_id->tid = tid;

    if (write_id->undo_data == nullptr) {
        VERBOSE_PRINT(do_verbose, "ERROR: can't allocate memory\n");
		GTFS_UNLOCK;
        return nullptr;
    }

    memcpy(write_id->undo_data, write_id->data + offset, length);

    fl->trans_queue.emplace_back(write_id);
    g_trans_map.emplace(tid, fl);

    memcpy(write_id->data + offset, data, length);

    VERBOSE_PRINT(do_verbose, "content of data\"" << write_id->data + offset <<"\"\n");
    VERBOSE_PRINT(do_verbose, "content of undo_data\"" << write_id->undo_data <<"\"\n");

	GTFS_UNLOCK;

    VERBOSE_PRINT(do_verbose, "Success\n"); //On success returns non NULL.
    return write_id.get();
}

int gtfs_sync_write_file(write_t* write_id) {
    int ret = -1;
    if (write_id) {
        VERBOSE_PRINT(do_verbose, "Persisting write of " << write_id->length << " bytes starting from offset " << write_id->offset << " inside file " << write_id->filename << "\n");
    } else {
        VERBOSE_PRINT(do_verbose, "Write operation does not exist\n");
        return ret;
    }
    //TODO: Add any additional initializations and checks, and complete the functionality
    GTFS_LOCK;

	if(!write_id->is_used)
	{
		VERBOSE_PRINT(do_verbose, "WARNING: write_id is invalid\n");
		GTFS_UNLOCK;
		return ret;
	}

    auto it = g_trans_map.find(write_id->tid);
    if (it == g_trans_map.end())
    {
        VERBOSE_PRINT(do_verbose, "ERROR: can't necessary file_t\n");
        GTFS_UNLOCK;
        return ret;
    }
    
    file_t* fl = it->second;
    
    struct stat st;

    // Write log
    int fd;

    // Check if log already exists
    if (stat(fl->log_filename.c_str(), &st) == 0) {
        VERBOSE_PRINT(do_verbose, "truncate log\n");
        //log truncation if log is more than 10K
        if (st.st_size > 102400) {
            gtfs_truncate_log(fl->home_filename, fl->log_filename);
        }
    }

    if(stat(fl->log_filename.c_str(), &st) != 0)
    {
        VERBOSE_PRINT(do_verbose, "create new log file " << fl->log_filename <<"\n");
        //create log
        fd = creat(fl->log_filename.c_str(), 00644);
        if (fd < 0) {
            VERBOSE_PRINT(do_verbose, "ERROR: can't create log for the home file!\n");
            GTFS_UNLOCK;
            return 0;
        }
        close(fd);
    }

    // Open log
    fd = open(fl->log_filename.c_str(), O_RDWR);
    if (fd < 0) {
        VERBOSE_PRINT(do_verbose, "ERROR: can't open log file!\n");
        GTFS_UNLOCK;
        return 0;
    }
	ret = 0;
    // Write the transition unit to the log
    if (lseek(fd, 0, SEEK_END) >= 0) {
        write(fd, &write_id->length, sizeof(int));
        write(fd, &write_id->offset, sizeof(int));
        ret += write(fd, (uint8_t*)write_id->data + write_id->offset, write_id->length);
        write_id->is_used = false;
    }

    close(fd);

    GTFS_UNLOCK;

    VERBOSE_PRINT(do_verbose, "Success\n"); //On success returns number of bytes written.
    return ret;
}

int gtfs_abort_write_file(write_t* write_id) {
    int ret = -1;
    if (write_id) {
        VERBOSE_PRINT(do_verbose, "Aborting write of " << write_id->length << " bytes starting from offset " << write_id->offset << " inside file " << write_id->filename << "\n");
    } else {
        VERBOSE_PRINT(do_verbose, "Write operation does not exist\n");
        return ret;
    }
    //TODO: Add any additional initializations and checks, and complete the functionality

    GTFS_LOCK;

	if (!write_id->is_used)
	{
		VERBOSE_PRINT(do_verbose, "WARNING: write_id is invalid\n");
		GTFS_UNLOCK;
		return ret;
	}

	write_id->is_used = false;
    VERBOSE_PRINT(do_verbose, "content of file: \"" << write_id->data + write_id->offset << "\"\n");
	memcpy(write_id->data + write_id->offset, write_id->undo_data, write_id->length);
    VERBOSE_PRINT(do_verbose, "after abort: \"" << write_id->data + write_id->offset << "\"\n");

	ret = 0;
	
    GTFS_UNLOCK;

    VERBOSE_PRINT(do_verbose, "Success.\n"); //On success returns 0.
    return ret;
}

// BONUS: Implement below API calls to get bonus credits

int gtfs_clean_n_bytes(gtfs_t *gtfs, int bytes){
    int ret = -1;
    if (gtfs) {
        VERBOSE_PRINT(do_verbose, "Cleaning up [ " << bytes << " bytes ] GTFileSystem inside directory " << gtfs->dirname << "\n");
    } else {
        VERBOSE_PRINT(do_verbose, "GTFileSystem does not exist\n");
        return ret;
    }

    VERBOSE_PRINT(do_verbose, "Success\n"); //On success returns 0.
    return ret;
}

int gtfs_sync_write_file_n_bytes(write_t* write_id, int bytes){
    int ret = -1;
    if (write_id) {
        VERBOSE_PRINT(do_verbose, "Persisting [ " << bytes << " bytes ] write of " << write_id->length << " bytes starting from offset " << write_id->offset << " inside file " << write_id->filename << "\n");
    } else {
        VERBOSE_PRINT(do_verbose, "Write operation does not exist\n");
        return ret;
    }

	GTFS_LOCK;

	if (!write_id->is_used)
	{
		VERBOSE_PRINT(do_verbose, "WARNING: write_id is invalid\n");
		GTFS_UNLOCK;
		return ret;
	}

	auto it = g_trans_map.find(write_id->tid);
	if (it == g_trans_map.end())
	{
		VERBOSE_PRINT(do_verbose, "ERROR: can't find necessary file_t\n");
		GTFS_UNLOCK;
		return ret;
	}

	file_t* fl = it->second;

	struct stat st;

	// Write log
	int fd;

	// Check if log already exists
	if (stat(fl->log_filename.c_str(), &st) == 0) {
		VERBOSE_PRINT(do_verbose, "truncate log\n");
		//log truncation if log is more than 10K
		if (st.st_size > 102400) {
			gtfs_truncate_log(fl->home_filename, fl->log_filename);
		}
	}

	if (stat(fl->log_filename.c_str(), &st) != 0)
	{
		VERBOSE_PRINT(do_verbose, "create new log file " << fl->log_filename << "\n");
		//create log
		fd = creat(fl->log_filename.c_str(), 00644);
		if (fd < 0) {
			VERBOSE_PRINT(do_verbose, "ERROR: can't create log for the home file!\n");
			GTFS_UNLOCK;
			return 0;
		}
		close(fd);
	}

	// Open log
	fd = open(fl->log_filename.c_str(), O_RDWR);
	if (fd < 0) {
		VERBOSE_PRINT(do_verbose, "ERROR: can't open log file!\n");
		GTFS_UNLOCK;
		return 0;
	}
	ret = 0;
	auto length_to_wrtite = write_id->length> bytes?bytes: write_id->length;
	// Write the transition unit to the log
	if (lseek(fd, 0, SEEK_END) >= 0) {
		write(fd, &write_id->length, sizeof(int));
		write(fd, &write_id->offset, sizeof(int));
		ret += write(fd, (uint8_t*)write_id->data + write_id->offset, length_to_wrtite);
		write_id->is_used = false;
	}

	close(fd);

	GTFS_UNLOCK;

    VERBOSE_PRINT(do_verbose, "Success\n"); //On success returns 0.
    return ret;
}

bool gtfs_truncate_log(string home_file_name, string log_file_name) {
    struct stat st;
    int fd;
    int log_fd;

    VERBOSE_PRINT(do_verbose, "truncate log file\n");

    // Check if log already exists
    if (stat(log_file_name.c_str(), &st) != 0) {
        VERBOSE_PRINT(do_verbose, "log file not exists\n");
        // No log
        return true;
    }
    // Open log
    log_fd = open(log_file_name.c_str(), O_RDWR);
    if (log_fd < 0) {
        VERBOSE_PRINT(do_verbose, "ERROR: can't open log file\n");
        return false;
    }

    if (stat(home_file_name.c_str(), &st) != 0) {
        VERBOSE_PRINT(do_verbose, "ERROR: No home file found!\n");
        close(log_fd);
        return false;
    }


    fd = open(home_file_name.c_str(), O_RDWR);
    if (fd < 0) {
        VERBOSE_PRINT(do_verbose, "ERROR: can't open home file\n");
        close(log_fd);
        return false;
    }

    // Get the end of file
    int filesize = lseek(log_fd, 0, SEEK_END);

    int data_size = 0;
    int offset = 0;

    vector<char> buffer(sizeof(int));
    int curr_offset = 0;

    lseek(log_fd, 0, SEEK_SET);

    VERBOSE_PRINT(do_verbose, "log file size " << filesize << "\n");

    // Read data and its information
    while (curr_offset < filesize) {
        curr_offset += read(log_fd, buffer.data(), sizeof(int));
        data_size = *((int *)buffer.data());

        curr_offset += read(log_fd, buffer.data(), sizeof(int));
        offset = *((int *)buffer.data());

        buffer.resize(data_size);
        curr_offset += read(log_fd, buffer.data(), data_size);

        if (lseek(fd, offset, SEEK_SET) >= 0) {
            write(fd, buffer.data(), data_size);
            VERBOSE_PRINT(do_verbose, "write to home file starting from offset " << offset << "with data size " << data_size << "\n");
        }
    }

    close(log_fd);
    close(fd);
    
    remove(log_file_name.c_str());

    return true;
}

int gtfs_close_file_and_clean(file_t* fl)
{
	gtfs_truncate_log(fl->home_filename, fl->log_filename);

	if (fl->mapped_data) {
		free(fl->mapped_data);
		fl->mapped_data = nullptr;
		fl->is_mapped = false;
	}
	while (!fl->trans_queue.empty())
	{
		auto trans = fl->trans_queue.back();
		free(trans->undo_data);
		trans->undo_data = nullptr;
		trans->is_used = false;
		auto it = g_trans_map.find(trans->tid);
		if (it != g_trans_map.end())
			g_trans_map.erase(it);
		fl->trans_queue.pop_back();
	}

	fl->is_used = false;
	fl->trans_queue.clear();
	return 0;
}
